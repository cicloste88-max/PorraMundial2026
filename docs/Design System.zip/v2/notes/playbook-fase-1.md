# Playbook Fase 1 — Espejo móvil 1:1

> Documento de trabajo. Lo vamos marcando juntos a medida que avanzamos.
> Última actualización: inicio de Fase 1.

---

## 0 · Decisiones cerradas (no volvemos a debatirlas)

| Decisión | Valor |
|---|---|
| Device | iPhone 375×812 con frame iOS realista |
| Fidelidad | Refresh editorial — identidad mantenida, jerarquía/espaciado/tipografía pulidos |
| Scope | Las 8 pantallas del inventario |
| Variantes | Todas las sub-vistas como artboards independientes (~14 mesas) |
| Interactividad | Completa — pickers, sliders, boost, navegación, todo responde |
| Datos | Oficiales del Mundial 2026 (`uploads/data.js` — 48 equipos, GRUPOS, PARTIDOS, BRACKET) |
| Tipografía | Stack actual + `fonts/fifa-26-v2.otf` para títulos display |
| Mejoras | Espejo PURO. Cero refactor de arquitectura. Mejoras → Fase 2 |
| Orden | Empezamos por **match card aislada** → grupos → resto |

---

## 1 · Estructura de archivos que voy a crear

```
v2/
├── App.html                    ← entry point (design canvas + 14 artboards)
├── app/
│   ├── shell.jsx               ← <Artboard>, frame iOS reutilizable
│   ├── tokens.css              ← colors, type scale, spacing, radii
│   ├── data.js                 ← clon limpio de uploads/data.js
│   ├── state.js                ← predictions, totalPoints, getMatchKey, etc.
│   │
│   ├── components/
│   │   ├── MatchCard.jsx       ← ⭐ átomo principal (empezamos aquí)
│   │   ├── JCard.jsx           ← variante para vista jornada
│   │   ├── DCard.jsx           ← variante directo
│   │   ├── KOCard.jsx          ← variante eliminatorias
│   │   ├── FlagBadge.jsx
│   │   ├── ScorePicker.jsx
│   │   ├── BoostToggle.jsx
│   │   ├── StatusPill.jsx
│   │   ├── BracketRail.jsx
│   │   ├── StadiumChip.jsx
│   │   ├── PodiumStand.jsx
│   │   ├── AwardsPicker.jsx
│   │   ├── IABar.jsx
│   │   ├── DiceModal.jsx
│   │   └── SplashHero.jsx
│   │
│   └── screens/
│       ├── 01-Welcome.jsx
│       ├── 02a-AuthLogin.jsx
│       ├── 02b-AuthRegister.jsx
│       ├── 03-Ligas.jsx
│       ├── 04a-Grupos-Cards.jsx       ← sub-tab "tarjetas"
│       ├── 04b-Grupos-Jornada.jsx     ← sub-tab "jornada"
│       ├── 04c-Grupos-Directo.jsx     ← sub-tab "directo"
│       ├── 05-Directo.jsx              ← pantalla directo standalone
│       ├── 06a-Elim-Bracket.jsx        ← vista bracket
│       ├── 06b-Elim-Lista.jsx          ← vista lista
│       ├── 06c-Elim-Stadium.jsx        ← vista podio/stadium
│       ├── 07-Clasificacion.jsx
│       └── 08-Admin.jsx
```

Total: **14 artboards** dentro de **1 design canvas** en `App.html`.

---

## 2 · Sistema de tokens (definir antes de tocar pantallas)

Reciclo la paleta detectada en Fase 0, documentada como variables CSS. Nada inventado todavía — esto es espejo.

```css
:root {
  /* Color (extraído de styles.css + welcome.css + boost.css) */
  --bg: #0b0d10;
  --surface: #15181d;
  --surface-2: #1c2027;
  --line: rgba(255,255,255,.08);
  --text: #f5f6f8;
  --text-dim: #9aa1ad;
  --accent: #ff5a1f;       /* boost / CTA */
  --accent-2: #16a34a;     /* aciertos */
  --warn: #f59e0b;
  --gold: #fbbf24;

  /* Type */
  --display: "FIFA 26", "Inter Tight", system-ui, sans-serif;
  --sans: "Inter", system-ui, sans-serif;
  --mono: ui-monospace, monospace;

  /* Spacing */
  --s-1: 4px;  --s-2: 8px;  --s-3: 12px;
  --s-4: 16px; --s-5: 24px; --s-6: 32px;

  /* Radii */
  --r-sm: 8px; --r-md: 12px; --r-lg: 16px; --r-xl: 24px;
}
```

Si en Fase 2 cambiamos algo, sólo se toca aquí.

---

## 3 · Plan de ejecución (ordenado, atómico)

### Bloque A · Setup (sin pantallas todavía)
- [ ] A1. Crear `v2/App.html` con design canvas vacío + import del frame iOS
- [ ] A2. Copiar `uploads/data.js` → `v2/app/data.js` (sin tocar)
- [ ] A3. Crear `v2/app/tokens.css` con variables del bloque 2
- [ ] A4. Crear `v2/app/shell.jsx` con `<Artboard label width=375 height=812>` envuelto en frame iOS
- [ ] A5. Cargar fuente FWC (`fonts/fifa-26-v2.otf`) vía `@font-face`

**Salida esperada:** `App.html` carga y muestra un canvas vacío con frame iOS placeholder. **Pausa: te lo enseño.**

### Bloque B · Componente átomo (lo que pediste primero)
- [ ] B1. Crear `MatchCard.jsx` con TODOS los estados:
  - Estado neutral (sin pick)
  - Estado con pick del usuario
  - Estado con pick + boost activo
  - Estado finalizado acierto exacto
  - Estado finalizado acierto signo
  - Estado finalizado fallo
  - Estado en directo (con minuto)
- [ ] B2. Mostrarlo en `App.html` como **primer artboard suelto** (375 ancho, los 7 estados apilados)

**Salida esperada:** vemos las 7 variantes una sobre otra. **Pausa: iteramos hasta que apruebes.**

### Bloque C · Componentes hermanos
- [ ] C1. JCard, DCard, KOCard (variantes de match card)
- [ ] C2. ScorePicker, BoostToggle, StatusPill, FlagBadge, StadiumChip
- [ ] C3. Mostrarlos en un artboard "Component Library" (375 ancho, lista de todos)

### Bloque D · Pantallas en orden
1. [ ] 04a Grupos · Cards (la más usada, prueba todos los componentes anteriores)
2. [ ] 04b Grupos · Jornada
3. [ ] 04c Grupos · Directo
4. [ ] 06a Elim · Bracket
5. [ ] 06b Elim · Lista
6. [ ] 06c Elim · Stadium
7. [ ] 07 Clasificación
8. [ ] 05 Directo standalone
9. [ ] 03 Ligas
10. [ ] 01 Welcome
11. [ ] 02a Auth Login
12. [ ] 02b Auth Register
13. [ ] 08 Admin

### Bloque E · Cierre Fase 1
- [ ] E1. Verificar que las 14 mesas cargan sin errores
- [ ] E2. Verificar que cada interacción definida en Fase 0 funciona
- [ ] E3. Actualizar `Inventario.html` marcando qué quedó en espejo
- [ ] E4. Documento `v2/notes/fase-1-cierre.md` con: qué quedó pendiente, qué descubrimos, qué proponer en Fase 2

---

## 4 · Reglas de ejecución (las mías)

1. **Nada de inventar.** Si una pantalla tiene un comportamiento ambiguo, lo marco con `// TODO ASK` y te pregunto antes de seguir.
2. **Componentes en archivos separados.** Nada de un mega-archivo. Máximo ~250 líneas por archivo JSX.
3. **Datos reales siempre.** Nunca placeholders genéricos — siempre desde `data.js`.
4. **Cada bloque termina con pausa visual.** No avanzo al siguiente sin que lo veas.
5. **Tweaks panel desde el bloque A.** Mínimo: cambiar device width, toggle dark/light, toggle "mostrar acotaciones".
6. **Cero refactor.** Si veo algo que mejoraría, lo anoto en `propuestas-fase-2.md` y sigo.

---

## 5 · Checklist de paridad (lo verificamos al cierre de cada pantalla)

Para cada pantalla, antes de marcar ✓:
- [ ] Mismos componentes visibles que producción
- [ ] Misma jerarquía (header, body, sub-tabs, footer si aplica)
- [ ] Mismas interacciones definidas en Fase 0
- [ ] Datos coherentes (no cruzados entre grupos)
- [ ] Estados vacío / con datos / finalizado contemplados
- [ ] Sub-vistas mobile específicas reflejadas (ui-groups-mobile.js)
- [ ] Sin errores de consola

---

## 6 · Convenciones de naming

- Mesas (artboards): `NN-Nombre` (`04a-Grupos-Cards`)
- Componentes: `PascalCase.jsx`
- Hooks: `useXxx`
- Estado global expuesto: `window.PORRA = { predictions, totalPoints, ... }`
- IDs de artboard para design-canvas: igual que el nombre de archivo sin extensión

---

## 7 · Estado del playbook

Marca cada bloque cuando lo aprobemos juntos.

- [x] Bloque A · Setup (25-abr-2026) — tokens.css + shell.jsx + data.js + App.html con 16 artboards placeholder
- [x] Bloque B · Match card átomo (25-abr-2026) — 8 estados coherentes: ciclo de vida real (vacía → rellenando → guardada → boost → cerrada → live → finalizado exacto/fallo) + porraCerrada. Boost coherente en cadena. FWC 26 en tnames/VS/scores.
- [x] Bloque C · Componentes hermanos (25-abr-2026) — JCard (6 estados), DCard (5 estados), KOCard (5 estados) con CSS espejo producción
- [ ] Bloque D · Pantallas (14)
- [ ] Bloque E · Cierre

---

## 8 · Pendientes de Fase 0 que arrastramos

- Lista exhaustiva de features a conservar — cubierta por `Inventario.html`. Si falta algo, lo añades como comentario sobre el inventario y lo recojo.
- Confirmar si `02-Auth` se trata como overlay o pantalla completa → asumimos **pantalla completa** (2 mesas: login y registro).

---

## 9 · Para Fase 2 (no tocar ahora, sólo anotar)

Conforme detecte cosas mejorables las anoto en `v2/notes/propuestas-fase-2.md`. Vacío al inicio.

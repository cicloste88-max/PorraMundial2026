# Propuestas para Fase 2

> Cosas que detecto durante el espejo y que podrían mejorar.
> NO se aplican en Fase 1. Las revisamos juntos al iniciar Fase 2.

- Variantes editoriales A/B/C rechazadas — mantenemos estética producción. Refresh editorial se descarta para tarjetas.

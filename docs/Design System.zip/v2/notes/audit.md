# Auditoría v1 — Porra Mundial 2026

## Repo
- GitHub: `cicloste88-max/PorraMundial2026` · branch `main`
- Stack: Vite + vanilla JS + Supabase (auth + storage + DB)
- Producción: Vercel (no tocar)

## Assets (Supabase Storage)
Base: `https://cmyfyswystjgzdwbqyyb.supabase.co/storage/v1/object/public`

| Bucket | Patrón | Uso |
|---|---|---|
| `flags` | `/flags/{FIFA}.png` redondas | Listas, jornada, KO |
| `kits` | `/kits/{FIFA}_home.png` y `_away.png` | Match cards (kit-bg) |
| `miniatures` | `/miniatures/Logos/...png`, stickers, balón Trionda | Awards, hero, vs-ball |
| `sites` | Posters 16 sedes | Welcome venues, KO hero |

Logo torneo: `/miniatures/Logos/2026_FIFA_World_Cup.png`
Balón: `/miniatures/Ball/Trionda-official-ball.png`

## Tokens visuales

### Colors
```
--bg        #0f172a    (welcome usa #06060a)
--card      #1c1c1e
--deep      #111318
--border    #27272a    --border-hi #3a3a3e
--text-1    #f0fdf4    --text-2 #9ca3af  --text-3 #6b7280
--green     #4ade80    --green-bg #052e16  --green-bd #166534
--amber     #fcd34d    --amber-bg #1c1003  --amber-bd #d97706
--blue      #93c5fd    --blue-bg #0c2340   --blue-bd #1d4ed8
--purple    #c4b5fd
--gold      #fcd34d
Live red:   #f75f5f / #ef4444
Boost:      #fb923c / #ea580c (naranja fuego)
```

### Tipografía
- `Inter` — body
- `Inter Tight` — display, números (peso 900)
- `Bebas Neue` — welcome titulares
- Fuente FWC 26 disponible localmente para v2

## Familias de componentes v1

| Componente | Prefijo | Archivo CSS | Pantalla |
|---|---|---|---|
| Match card grupos (kit-bg + boost) | `.card .hero .half .kit-bg .flag-circle .vs-b` | base.css | Grupos (vista cards) |
| Jornada compacta | `.jcard .jcard-stripe .jcard-pts` | base.css | Grupos (vista jornada) |
| Directo (live) | `.dcard .dcard-status-pill .dcard-events` | directo.css | Tab Directo |
| Tabla clasificación | `.gc-table .qual-badge .gc-prog-dots` | base.css | Lateral grupos |
| Awards picker | `.aw-card .aw-slot .aw-picker` | base.css (mover a awards.css) | Premios |
| KO cinematic | `.ko-card .ko-hero .ko-flag .ko-vs-circle` | ko.css | KO vista C |
| KO bracket horizontal | `.br-col .br-card .br-trophy` | ko.css | KO vista A |
| KO stadium | `.st-card .st-final-card .pitch` | ko.css | KO vista B |
| Bracket results timeline | `.brk-sect .brk-mc .brk-live-hero .brk-rail` | bracket-results.css | Seguimiento KO |
| Welcome | `.wc-hero .wc-mosaic .wc-card .wc-vp-card` | welcome.css | Landing |
| Auth modal | `.auth-overlay .auth-modal .auth-tabs` | welcome.css | Login/registro |
| Header global sticky | `.global-header .gh-back .gh-pts .gh-clasif` | base.css/ko.css | Todas las páginas |
| Sub-tabs vistas | `.view-tabs .view-tab` | base.css/ko.css | Selector vistas KO |
| Splash screen | `#splash-screen .spl-*` | ko.css | Carga inicial |
| Finalizar pronósticos | `.finalizar-card .fin-check` | ko.css | Submit final KO |

## Sistemas

### Boost (comodín x2)
- Archivo aislado: `boost.css`
- Clases: `.boost-row .boost-chk .boost-badge .card.boost-active`
- Animaciones: `boost-glow`, `boost-flicker`, partículas en canvas `#boost-fire-canvas`
- Color: naranja-rojo `rgba(234,88,12,*)`, `rgba(239,68,68,*)`
- Glow naranja siempre = "boost activado x2"

### IA bar (predicción)
- `.ia-bar .ia-prediction .ia-loading .ia-dot`
- Color púrpura `#7c3aed / #c4b5fd`

### Status pills (vida del partido)
`.status-pill.open|.closing|.closed|.live|.done` — verde/naranja/gris/rojo/azul
`.dcard-status-pill.live|.halftime|.overtime|.penalties|.final|.notstarted`
`.ko-status.open|.locked|.pending|.saved|.done|.live|.gold`

### Puntos animados
`.ptc.sign|.exact|.scorer|.ia|.potential` con fade-in escalonado

### Clasificación
`tr.qualified` (verde), `tr.best-third` (ámbar), `tr.eliminated` (gris)
`.qual-badge.in|.prov|.out`

## Datos (data.js)
- 48 selecciones, 12 grupos A-L (4 equipos cada uno)
- Cada equipo: `{flag: "ESP", slug: "spain", group: "H", color1, color2}`
- BRACKET object con estructura R32 → R16 → QF → SF → 3rd → Final

## Decisiones para v2
- Mantener tokens de color (green/amber/blue/purple/gold + boost orange)
- Mantener fuente Inter + Inter Tight (añadir FWC 26 para hero)
- Mantener Bebas Neue para títulos welcome (o reemplazar por FWC 26)
- Mantener TODAS las pantallas y features (espejo 1:1 antes de mejoras)
- Mantener URLs de Supabase Storage tal cual (CDN ya cacheado)

## Pantallas a recrear en v2
1. **Welcome / landing** (`page-welcome`) — hero con mosaic + reglas + venues
2. **Auth modal** — login + registro (Supabase Auth)
3. **Grupos** — cards (boost) + jornada + clasificación lateral
4. **Directo** — live scores con eventos
5. **Premios** — picker de 4 awards
6. **KO** — 3 vistas: cinematic / bracket horizontal / stadium
7. **Seguimiento KO** (bracket-results) — timeline vertical con live hero
8. **Header global sticky** — back + título + pts + sub-tabs
9. **Splash** — logo bouncing al entrar

## Sistema de puntos (de scoring.js)

### Por partido (grupos + KO)
- +1 pt → signo correcto (1·X·2)
- +3 pts → marcador exacto (incluye signo, no acumula con +1)
- +2 pts → goleador correcto (sólo si no es 0-0 y aciertas un goleador del bando ganador)
- +1 pt → bonus vs IA (tu signo difiere del de la IA y aciertas)
- **Cap: 7 pts/partido** (pre-boost)
- **Boost ×2** si exacto + ese partido es el boost del día → hasta 14 pts

### KO — bonus por equipos que avanzan
| Ronda | Pts por equipo |
|---|---|
| Pasa de grupos → 1/16 | +5 |
| Avanza en 1/16 → octavos | +5 |
| Avanza en octavos → cuartos | +10 |
| Avanza en cuartos → semis | +15 |
| Avanza en semis → final | +20 |
| Llega a la final | +25 (extra al ganar SF) |

### Clasificación final
- Campeón: +30
- Subcampeón: +20
- 3º: +15
- 4º: +10

### Premios individuales (4)
- Balón de Oro: +15
- Bota de Oro: +15
- Guante de Oro: +15
- Mejor Joven Sub-21: +20

### Estados de partido (getEstadoPartido)
- `open` → > 4d antes del kickoff
- `closing` → entre 4d y 2d antes
- `closed` → < 2d antes (no edición)
- `live` → durante 95min tras kickoff
- `done` → tras 95min

## Estructura de páginas (index.html)
- `#splash-screen` → splash inicial 4-10s
- `#wc-auth-bar` (sticky) + `#auth-overlay` (login modal)
- `#page-welcome` → hero + reglas + venues + bottom CTA
  - `#league-panel` overlay dentro del hero (lista ligas + crear/unirse)
  - `#league-modal-create` / `#league-modal-join`
- `#page-grupos` → tabs (grupos / jornada / directo) + container + CTA eliminatorias
- `#page-elim` → tabs (cinematic / bracket-results / stadium) + finalizar-section
- `#page-score` → ranking multi-usuario (podio + tabla + breakdown personal)
- `#page-admin` → panel admin (resultados / usuarios / premios / sistema)
- `#aw-overlay` → picker de premios

## Pantallas adicionales descubiertas
- **Scoreboard** (`#page-score`): podio top-3 + tabla GRP/ELM/AWD/TOTAL + mi desglose
- **Admin** (`#page-admin`): tabs Resultados / Usuarios / Premios / Sistema
- **Modales liga**: crear (nombre) y unirse (código 6 letras)
- **Locked screen** en KO si grupos < 72/72
- **Finalizar pronósticos**: 4 checks (grupos / KO / awards / boost)
- **Ticker boost** + **dice global bar** (simular)

## Pendiente Fase 0
- (Ya cubierto el grueso. ui-directo y bracket-results se leerán según necesidad en Fase 1)

// shell.jsx — Porra Mundial 2026 · v2
// Artboard wrapper: frame iOS + screen container
// Usage: <Artboard label="04a · Grupos"><MyScreen/></Artboard>

function Artboard({ children, label, dark = true }) {
  return (
    <IOSDevice width={375} height={812} dark={dark}>
      <div className="porra-screen" style={{ background: dark ? 'var(--bg)' : '#fff' }}>
        {children}
      </div>
    </IOSDevice>
  );
}

Object.assign(window, { Artboard });

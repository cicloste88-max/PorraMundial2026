// components.jsx — UI atoms for FIFA WC 2026 app

const FLAGS = {
  MEX: '🇲🇽', USA: '🇺🇸', CAN: '🇨🇦', ARG: '🇦🇷', BRA: '🇧🇷',
  ESP: '🇪🇸', FRA: '🇫🇷', GER: '🇩🇪', ENG: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', POR: '🇵🇹',
  NED: '🇳🇱', ITA: '🇮🇹', BEL: '🇧🇪', URU: '🇺🇾', JPN: '🇯🇵',
  KOR: '🇰🇷', AUS: '🇦🇺', MAR: '🇲🇦', SEN: '🇸🇳', CRO: '🇭🇷',
  RSA: '🇿🇦', CZE: '🇨🇿',
};

const C_NAMES = {
  MEX: 'México', USA: 'Estados Unidos', CAN: 'Canadá', ARG: 'Argentina', BRA: 'Brasil',
  ESP: 'España', FRA: 'Francia', GER: 'Alemania', ENG: 'Inglaterra', POR: 'Portugal',
  NED: 'Países Bajos', ITA: 'Italia', BEL: 'Bélgica', URU: 'Uruguay', JPN: 'Japón',
  KOR: 'Corea', AUS: 'Australia', MAR: 'Marruecos', SEN: 'Senegal', CRO: 'Croacia',
  RSA: 'Sudáfrica', CZE: 'Rep. Checa',
};

function Flag({ code, size = 'md' }) {
  const cls = size === 'xl' ? 'flag flag-xl' : size === 'lg' ? 'flag flag-lg' : 'flag';
  return <div className={cls}>{FLAGS[code] || '⚽'}</div>;
}

function Icon({ name, size = 22, color = 'currentColor', stroke = 1.8 }) {
  const p = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (name) {
    case 'home': return <svg {...p}><path d="M3 11l9-7 9 7v9a2 2 0 01-2 2h-4v-7h-6v7H5a2 2 0 01-2-2v-9z"/></svg>;
    case 'cal': return <svg {...p}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>;
    case 'live': return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M5.6 5.6a9 9 0 000 12.8M18.4 5.6a9 9 0 010 12.8M8.5 8.5a5 5 0 000 7M15.5 8.5a5 5 0 010 7"/></svg>;
    case 'pred': return <svg {...p}><path d="M12 2l2.4 7.2H22l-6.2 4.5 2.4 7.3L12 16.5 5.8 21l2.4-7.3L2 9.2h7.6L12 2z"/></svg>;
    case 'profile': return <svg {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/></svg>;
    case 'bell': return <svg {...p}><path d="M6 8a6 6 0 1112 0c0 7 3 7 3 9H3c0-2 3-2 3-9zM10 21a2 2 0 004 0"/></svg>;
    case 'search': return <svg {...p}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>;
    case 'trophy': return <svg {...p}><path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 01-10 0V4zM7 6H4a3 3 0 003 3M17 6h3a3 3 0 01-3 3"/></svg>;
    case 'flame': return <svg {...p}><path d="M12 2c1 4 5 5 5 10a5 5 0 11-10 0c0-2 1-3 2-4-1 3 1 4 1 4s-1-3 2-6c1 2 0 4 0 4z"/></svg>;
    case 'lock': return <svg {...p}><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 018 0v4"/></svg>;
    case 'check': return <svg {...p}><path d="M5 12l5 5 9-11"/></svg>;
    case 'chev-r': return <svg {...p}><path d="M9 6l6 6-6 6"/></svg>;
    case 'chev-d': return <svg {...p}><path d="M6 9l6 6 6-6"/></svg>;
    case 'plus': return <svg {...p}><path d="M12 5v14M5 12h14"/></svg>;
    case 'minus': return <svg {...p}><path d="M5 12h14"/></svg>;
    case 'tv': return <svg {...p}><rect x="3" y="5" width="18" height="13" rx="2"/><path d="M8 21h8"/></svg>;
    case 'pin': return <svg {...p}><path d="M12 22s7-7 7-12a7 7 0 10-14 0c0 5 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/></svg>;
    default: return null;
  }
}

function LiveBadge() {
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:5, padding:'3px 7px', borderRadius:5, background:'rgba(227,6,19,0.1)', color:'var(--fifa-red)', fontFamily:'var(--font-display)', fontSize:10, fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase' }}>
      <span className="fc-live-dot"></span>EN VIVO
    </span>
  );
}

function StatusPill({ kind, children }) {
  const map = {
    final: { bg:'#F2F4F8', fg:'#4A5163' },
    upcoming: { bg:'#FFF8E1', fg:'#9A7B3A' },
    today: { bg:'#E8F1FF', fg:'#0A4595' },
  };
  const s = map[kind] || map.upcoming;
  return <span className="pred-chip" style={{ background:s.bg, color:s.fg }}>{children}</span>;
}

// Match card — Style A (classic)
function MatchA({ home, away, hs, as, status='upcoming', when, venue }) {
  return (
    <div className="fc-match-A">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 12 }}>
        <span className="fc-eyebrow">{when}</span>
        {status === 'live' ? <LiveBadge/> : status === 'final' ? <StatusPill kind="final">Final</StatusPill> : <StatusPill kind="today">{when}</StatusPill>}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr auto 1fr', alignItems:'center', gap: 12 }}>
        <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
          <Flag code={home} size="lg"/>
          <div>
            <div style={{ fontWeight:700, fontSize:15 }}>{C_NAMES[home]}</div>
            <div style={{ fontSize:11, color:'var(--ink-400)' }}>{home}</div>
          </div>
        </div>
        <div style={{ textAlign:'center' }}>
          {hs != null ? (
            <div className="score" style={{ fontSize: 28 }}>{hs}<span style={{ color:'var(--ink-300)', margin:'0 6px' }}>:</span>{as}</div>
          ) : (
            <div className="score" style={{ fontSize: 16, color:'var(--ink-400)' }}>VS</div>
          )}
        </div>
        <div style={{ display:'flex', alignItems:'center', gap: 10, justifyContent:'flex-end' }}>
          <div style={{ textAlign:'right' }}>
            <div style={{ fontWeight:700, fontSize:15 }}>{C_NAMES[away]}</div>
            <div style={{ fontSize:11, color:'var(--ink-400)' }}>{away}</div>
          </div>
          <Flag code={away} size="lg"/>
        </div>
      </div>
      {venue && (
        <div style={{ marginTop: 12, paddingTop: 10, borderTop:'1px dashed var(--ink-200)', display:'flex', alignItems:'center', gap: 6, fontSize: 11, color:'var(--ink-500)' }}>
          <Icon name="pin" size={12}/>{venue}
        </div>
      )}
    </div>
  );
}

// Match card — Style B (editorial / dark)
function MatchB({ home, away, hs, as, status='upcoming', when, venue, minute }) {
  return (
    <div className="fc-match-B">
      <div style={{ position:'absolute', right: -40, top: -40, width: 160, height: 160, borderRadius:'50%', background:'radial-gradient(circle, rgba(201,169,97,0.18) 0%, transparent 70%)' }}/>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 16, position:'relative' }}>
        <span className="fc-eyebrow" style={{ color:'rgba(255,255,255,0.5)' }}>{venue}</span>
        {status === 'live' ? (
          <span style={{ display:'inline-flex', alignItems:'center', gap:6, fontFamily:'var(--font-display)', fontSize:10, fontWeight:700, letterSpacing:'0.1em', color:'#fff' }}>
            <span className="fc-live-dot"></span>{minute}'
          </span>
        ) : (
          <span className="fc-eyebrow" style={{ color:'rgba(255,255,255,0.7)' }}>{when}</span>
        )}
      </div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', position:'relative' }}>
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:8, width: 80 }}>
          <Flag code={home} size="xl"/>
          <div style={{ fontFamily:'var(--font-display)', fontSize:13, fontWeight:700, letterSpacing:'0.04em' }}>{home}</div>
        </div>
        <div style={{ flex:1, textAlign:'center' }}>
          {hs != null ? (
            <div className="score" style={{ fontSize: 44, color:'#fff' }}>
              <span>{hs}</span><span style={{ color:'rgba(255,255,255,0.3)', margin:'0 10px' }}>−</span><span>{as}</span>
            </div>
          ) : (
            <div style={{ fontFamily:'var(--font-display)', fontSize:30, fontWeight:700, color:'rgba(255,255,255,0.3)' }}>VS</div>
          )}
        </div>
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:8, width: 80 }}>
          <Flag code={away} size="xl"/>
          <div style={{ fontFamily:'var(--font-display)', fontSize:13, fontWeight:700, letterSpacing:'0.04em' }}>{away}</div>
        </div>
      </div>
    </div>
  );
}

// Match card — Style C (compact data row)
function MatchC({ home, away, hs, as, when, status }) {
  return (
    <div className="fc-match-C">
      <Flag code={home}/>
      <div style={{ fontWeight:600, fontSize:13 }}>{C_NAMES[home]}</div>
      <div className="score" style={{ fontSize: 15, minWidth: 38, textAlign:'center', color: hs!=null?'var(--ink-900)':'var(--ink-400)' }}>
        {hs != null ? `${hs}–${as}` : when}
      </div>
      <div style={{ fontWeight:600, fontSize:13, textAlign:'right' }}>{C_NAMES[away]}</div>
      <Flag code={away}/>
    </div>
  );
}

function MatchCard({ style='A', ...rest }) {
  if (style === 'B') return <MatchB {...rest}/>;
  if (style === 'C') return <MatchC {...rest}/>;
  return <MatchA {...rest}/>;
}

Object.assign(window, { Flag, Icon, LiveBadge, StatusPill, MatchA, MatchB, MatchC, MatchCard, FLAGS, C_NAMES });

// MatchCard.jsx — Porra Mundial 2026 · v2
// Componente átomo principal: tarjeta de pronóstico de partido (fase de grupos).
// Espejo 1:1 de producción (scoring.js → createMatchCard + base.css + boost.css).
//
// Props:
//   match     — object from PARTIDOS {group, home, away, date, stadium}
//   idx       — index in PARTIDOS array
//   estado    — 'open'|'closing'|'closed'|'live'|'done' (override for demo)
//   pred      — {l, v, gol, saved} prediction state
//   ia        — {sign, confidence, quip} IA prediction
//   boostActive — boolean
//   onPredChange — (pred) => void
//   onBoostToggle — () => void
//   onSave    — () => void
//   onUndo    — () => void
//   onDice    — () => void

const SB_URL = 'https://cmyfyswystjgzdwbqyyb.supabase.co/storage/v1/object/public';

// Kit URL resolver (mirrors KIT_OVERRIDES from scoring.js)
const KIT_OV = {
  'irak':{ home:'local.png', away:'away.png' },
  'jordan':{ home:'local.png', away:'away.jpg' },
  'cape-verde':{ home:'home.png', away:'away.png' },
  'uzbekistan':{ home:'local.png', away:'local.png' },
  'drc-jam':{ home:'local.png', away:'away.png', folder:'rd congo' },
  'tunisia':{ home:'local.jpg', away:'away.jpg' },
  'curacao':{ home:'away.jpg', away:'away.jpg' },
  'uruguay':{ home:'home.png', away:'away.jpg' },
  'panama':{ home:'home.png', away:'away.png' },
};
function kitUrl(slug, type) {
  const ov = KIT_OV[slug];
  if (ov) {
    const folder = ov.folder || slug;
    const file = ov[type] || ov.home;
    return SB_URL + '/kits/' + encodeURIComponent(folder) + '/' + file;
  }
  return SB_URL + '/kits/' + slug + '/' + type + '.jpg';
}

const WHITE_KITS = new Set([
  'spain-home','england-home','germany-away','argentina-home',
  'usa-home','japan-home','korea-home','portugal-away','switzerland-home'
]);

const ONLY_AWAY = ['Túnez','Irak','Curazao'];

// ── Sub-components ──────────────────────────────────────────

function StatusPillV2({ estado, date, minute }) {
  const s = {
    open: { cls:'mc-pill-open', dot:'mc-dot-green', label: 'Abierta' },
    closing: { cls:'mc-pill-closing', dot:'mc-dot-amber', label: '¡Cierra pronto!' },
    closed: { cls:'mc-pill-closed', dot:'mc-dot-gray', label: 'Cerrada' },
    live: { cls:'mc-pill-live', dot:'mc-dot-live', label: `EN VIVO ${minute||67}'` },
    done: { cls:'mc-pill-done', dot:'mc-dot-blue', label: 'Finalizado' },
  }[estado] || { cls:'mc-pill-open', dot:'mc-dot-green', label:'Abierta' };
  return (
    <div className={`mc-status-pill ${s.cls}`}>
      <span className={`mc-sdot ${s.dot}`}></span>
      <span>{s.label}</span>
    </div>
  );
}

function ScoreBox({ value, side, onInc, onDec, frozen }) {
  const [bump, setBump] = React.useState(false);
  const handleInc = (dir) => {
    if (frozen) return;
    if (dir > 0) onInc(); else onDec();
    setBump(true);
    setTimeout(() => setBump(false), 220);
  };
  const display = value !== null && value !== undefined ? value : '—';
  const isOn = value !== null && value !== undefined;
  return (
    <div className="mc-score-col">
      <button className="mc-sbn" onClick={() => handleInc(1)} disabled={frozen}>▲</button>
      <div className={`mc-sbox ${isOn ? 'on' : ''} ${bump ? 'bump' : ''} ${frozen ? 'frozen' : ''}`}>
        {display}
      </div>
      <button className="mc-sbn" onClick={() => handleInc(-1)} disabled={frozen}>▼</button>
    </div>
  );
}

function PtsChip({ type, label, show }) {
  return <div className={`mc-ptc mc-ptc-${type} ${show ? 'show' : ''}`}>{label}</div>;
}

function GoalSelect({ match, pred, onSelect, frozen }) {
  const homeTeam = EQUIPOS.find(e => e.name === match.home);
  const awayTeam = EQUIPOS.find(e => e.name === match.away);
  const hOpts = homeTeam ? homeTeam.players : [];
  const aOpts = awayTeam ? awayTeam.players : [];
  return (
    <div className="mc-gol-row">
      <span className="mc-gol-lbl">Goleador</span>
      <div className="mc-gsel-wrap">
        <select
          className={`mc-gsel ${pred.gol ? 'sel' : ''}`}
          value={pred.gol || ''}
          onChange={e => onSelect(e.target.value || null)}
          disabled={frozen}
        >
          <option value="" disabled>Seleccionar jugador...</option>
          <optgroup label={match.home}>
            {hOpts.map(p => <option key={p.key} value={p.key}>{p.name}</option>)}
          </optgroup>
          <optgroup label={match.away}>
            {aOpts.map(p => <option key={p.key} value={p.key}>{p.name}</option>)}
          </optgroup>
        </select>
      </div>
      <span className={`mc-gbadge ${pred.gol ? 'on' : ''}`}>+2 pts</span>
    </div>
  );
}

function IABarV2({ ia, mySign }) {
  if (!ia || !ia.sign) return null;
  const signMap = { '1': 'Local', 'X': 'Empate', '2': 'Visitante' };
  const signLabel = signMap[ia.sign] || ia.sign;
  const conf = ia.confidence || 0;
  const showBonus = mySign && mySign !== ia.sign;
  return (
    <div className="mc-ia-bar">
      <div className="mc-ia-lbl"><span className="mc-ia-dot"></span>IA predice</div>
      <div className="mc-ia-content">
        <span className="mc-ia-pred">{ia.sign} · {signLabel} ({conf}%)</span>
        <span className="mc-ia-quip">{ia.quip || ''}</span>
      </div>
    </div>
  );
}

function BoostRowV2({ active, onToggle, frozen }) {
  return (
    <div className={`mc-boost-row ${active ? 'on' : ''}`}>
      <label className="mc-boost-label">
        <div className="mc-boost-chk-wrap">
          <input type="checkbox" className="mc-boost-chk" checked={active} onChange={onToggle} disabled={frozen}/>
          <div className="mc-boost-chk-box">
            {active && <svg width="11" height="9" viewBox="0 0 11 9" fill="none"><path d="M1 4.5L4 7.5L10 1" stroke="#fb923c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
          </div>
        </div>
        <span style={{ fontSize: 15, lineHeight: 1 }}>🔥</span>
        <span className="mc-boost-txt">Boost a este partido</span>
      </label>
      <span className="mc-boost-x2">×2</span>
    </div>
  );
}

// ── Main MatchCard ──────────────────────────────────────────

function MatchCard({
  match, idx = 0, estado = 'open', pred: predProp, ia, boostActive = false,
  onPredChange, onBoostToggle, onSave, onUndo, onDice,
  liveMinute, realHome, realAway,
  porraCerrada = false,
}) {
  const [pred, setPred] = React.useState(predProp || { l: null, v: null, gol: null, saved: false });

  React.useEffect(() => {
    if (predProp) setPred(predProp);
  }, [predProp]);

  const homeTeam = EQUIPOS.find(e => e.name === match.home);
  const awayTeam = EQUIPOS.find(e => e.name === match.away);
  if (!homeTeam || !awayTeam) return null;

  const hFlag = SB_URL + '/flags/' + homeTeam.flag + '.png';
  const aFlag = SB_URL + '/flags/' + awayTeam.flag + '.png';
  // Kit type logic: away team loads away kit by default.
  // If home team only has away kit (ONLY_AWAY), use away.
  // Kit conflict: if both kits share dominant green/white, force away on visitor.
  let hKitType = ONLY_AWAY.includes(match.home) ? 'away' : 'home';
  let aKitType = ONLY_AWAY.includes(match.away) ? 'away' : 'away';
  // Specific overrides from production (matching kit conflicts)
  const mkEx = match.home + '_' + match.away;
  if (mkEx === 'México_Sudáfrica') aKitType = 'away';
  if (mkEx === 'Japón_Suecia') aKitType = 'home';
  if (mkEx === 'Brasil_Marruecos') aKitType = 'home';
  if (mkEx === 'Túnez_Países Bajos') aKitType = 'home';
  const hKit = kitUrl(homeTeam.slug, hKitType);
  const aKit = kitUrl(awayTeam.slug, aKitType);
  const hWC = WHITE_KITS.has(homeTeam.slug + '-' + hKitType);
  const aWC = WHITE_KITS.has(awayTeam.slug + '-' + aKitType);

  // frozen = no editable (closed/done OR porra cerrada)
  const frozen = estado === 'closed' || estado === 'done' || porraCerrada;
  const isLive = estado === 'live';
  const isDone = estado === 'done';
  const hasScore = pred.l !== null && pred.v !== null;
  const mySign = hasScore ? (pred.l > pred.v ? '1' : pred.l < pred.v ? '2' : 'X') : null;

  const updatePred = (key, val) => {
    const next = { ...pred, [key]: val, saved: false };
    setPred(next);
    onPredChange?.(next);
  };

  const incScore = (side, dir) => {
    const cur = pred[side] === null ? 0 : pred[side];
    const next = Math.max(0, Math.min(9, cur + dir));
    updatePred(side, next);
  };

  // Pts calculation (simplified for display)
  let maxPts = 0;
  if (hasScore) {
    maxPts = 3; // exacto
    if (pred.gol) maxPts += 2;
    if (ia && mySign && mySign !== ia.sign) maxPts += 1;
    maxPts = Math.min(maxPts, 7);
  }
  if (boostActive && hasScore) maxPts = Math.min(maxPts * 2, 14);

  // Show chips
  const showSign = hasScore;
  const showExact = hasScore;
  const showScorer = !!pred.gol;
  const showIA = hasScore && ia && mySign && mySign !== ia.sign;

  const canSave = hasScore && !pred.saved && !frozen;

  return (
    <div className={`mc-card ${boostActive ? 'boost-active' : ''} mc-card-enter`}>
      <div className="mc-inner">
        {/* ── Hero: kits + flags + VS ── */}
        <div className="mc-hero">
          {/* Left half */}
          <div className="mc-half mc-half-L">
            <div className="mc-color-base"></div>
            <div className={`mc-kit-bg ${hWC ? 'white-kit' : ''}`} style={{ backgroundImage: `linear-gradient(to bottom, rgba(10,10,20,0.5) 0%, transparent 35%), linear-gradient(to bottom, transparent 60%, rgba(10,10,20,0.6) 100%), url('${hKit}')` }}></div>
            <div className="mc-vign mc-vign-L"></div>
            <div className="mc-team-info">
              <div className="mc-flag-circle">
                <img src={hFlag} alt={match.home} onError={e => { e.target.style.display='none'; }}/>
              </div>
              <div className="mc-tname">{match.home}</div>
              <div className="mc-trole">local</div>
            </div>
          </div>
          {/* Right half */}
          <div className="mc-half mc-half-R">
            <div className="mc-color-base"></div>
            <div className={`mc-kit-bg ${aWC ? 'white-kit' : ''}`} style={{ backgroundImage: `linear-gradient(to bottom, rgba(10,10,20,0.5) 0%, transparent 35%), linear-gradient(to bottom, transparent 60%, rgba(10,10,20,0.6) 100%), url('${aKit}')` }}></div>
            <div className="mc-vign mc-vign-R"></div>
            <div className="mc-team-info">
              <div className="mc-flag-circle">
                <img src={aFlag} alt={match.away} onError={e => { e.target.style.display='none'; }}/>
              </div>
              <div className="mc-tname">{match.away}</div>
              <div className="mc-trole">visitante</div>
            </div>
          </div>
          {/* Hero fade */}
          <div className="mc-hero-fade"></div>
          {/* Glow line */}
          <div className="mc-glow-line"></div>
          <div className="mc-spark" style={{ top:'18%' }}></div>
          <div className="mc-spark" style={{ top:'50%', animationDelay:'0.95s' }}></div>
          <div className="mc-spark" style={{ top:'76%', animationDelay:'1.9s' }}></div>
          {/* Center */}
          <div className="mc-center">
            <div className="mc-mpill">Grupo {match.group} · {match.stadium}</div>
            <div className="mc-vs-b">
              <div className="mc-vs-ball"></div>
              <span className="mc-vs-text">VS</span>
            </div>
            <StatusPillV2 estado={estado} date={match.date} minute={liveMinute}/>
          </div>
        </div>

        {/* ── Live score display (only when live/done with real results) ── */}
        {(isLive || isDone) && realHome != null && (
          <div className="mc-score-live">
            <div className="mc-score-big">
              <span className="mc-score-num">{realHome}</span>
              <span className="mc-score-sep">–</span>
              <span className="mc-score-num">{realAway}</span>
            </div>
            {hasScore && (
              <div className="mc-pred-sub">Tu pronóstico: <span>{pred.l} – {pred.v}</span></div>
            )}
          </div>
        )}

        {/* ── Prediction input ── */}
        {!(isLive && realHome != null) && !(isDone && realHome != null) && (
          <div className="mc-pred">
            <div className="mc-score-row">
              <ScoreBox value={pred.l} side="l" onInc={() => incScore('l', 1)} onDec={() => incScore('l', -1)} frozen={frozen}/>
              <div className="mc-ssep">:</div>
              <ScoreBox value={pred.v} side="v" onInc={() => incScore('v', 1)} onDec={() => incScore('v', -1)} frozen={frozen}/>
            </div>
            <div className="mc-pts-row">
              <PtsChip type="sign" label="🔵 +1pt signo" show={showSign}/>
              <PtsChip type="exact" label="🎯 +3pts exacto" show={showExact}/>
              <PtsChip type="scorer" label="⚽ +2pts goleador" show={showScorer}/>
              <PtsChip type="ia" label="🤖 +1pt vs IA" show={showIA}/>
            </div>
            <GoalSelect match={match} pred={pred} onSelect={v => updatePred('gol', v)} frozen={frozen}/>
          </div>
        )}

        {/* ── IA Bar ── */}
        <IABarV2 ia={ia} mySign={mySign}/>

        {/* ── Footer: dice + pts + save/undo ── */}
        <div className="mc-footer">
          <div className="mc-footer-left">
            {!porraCerrada && (
              <button className="mc-dice-btn" onClick={onDice} title="Simular al azar" style={{ display: frozen && !porraCerrada ? 'none' : undefined }}>
                <span>🎲</span>
              </button>
            )}
            <span>
              <span className={`mc-ptn ${hasScore ? 'on' : ''}`}>{maxPts}</span>
              <span className="mc-ptl">{porraCerrada ? ' pts' : ' pts posibles'}</span>
            </span>
          </div>
          <div className="mc-footer-right">
            {porraCerrada ? (
              <span className="mc-locked-badge">🔒 Cerrada</span>
            ) : pred.saved ? (
              <div className="mc-saved-group">
                <span className="mc-saved-badge">✓ Guardado</span>
                <button className="mc-btn-undo" onClick={() => { updatePred('saved', false); onUndo?.(); }}>↶ Deshacer</button>
              </div>
            ) : (
              <button className="mc-btn-save" disabled={!canSave} onClick={() => { const next = { ...pred, saved: true }; setPred(next); onSave?.(next); }}>
                Guardar
              </button>
            )}
          </div>
        </div>

        {/* ── Boost row (visible always if boost was set, frozen when closed) ── */}
        <BoostRowV2 active={boostActive} onToggle={() => !porraCerrada && !frozen ? onBoostToggle?.() : null} frozen={frozen || porraCerrada}/>
      </div>

      {/* ── Boost badge corner ── */}
      {boostActive && <div className="mc-boost-badge">×2</div>}
    </div>
  );
}

Object.assign(window, { MatchCard, StatusPillV2, ScoreBox, PtsChip, GoalSelect, IABarV2, BoostRowV2, kitUrl, SB_URL });

// JCard.jsx — Porra Mundial 2026 · v2
// Tarjeta compacta para vista Jornada (espejo de producción .jcard)
// Muestra: stripe color grupo · flags · equipos · marcador · puntos

function JCard({ match, pred, boostActive = false, estado = 'open', realHome, realAway, onClick }) {
  const homeTeam = EQUIPOS.find(e => e.name === match.home);
  const awayTeam = EQUIPOS.find(e => e.name === match.away);
  if (!homeTeam || !awayTeam) return null;

  const hFlag = SB_URL + '/flags/' + homeTeam.flag + '.png';
  const aFlag = SB_URL + '/flags/' + awayTeam.flag + '.png';
  const hasPred = pred && pred.l !== null && pred.v !== null;
  const isDone = estado === 'done';
  const isLive = estado === 'live';

  // Color por grupo
  const groupColors = {
    A:'#4ade80', B:'#60a5fa', C:'#f472b6', D:'#fb923c',
    E:'#a78bfa', F:'#fbbf24', G:'#34d399', H:'#f87171',
    I:'#93c5fd', J:'#c084fc', K:'#fcd34d', L:'#6ee7b7',
  };
  const gc = groupColors[match.group] || '#4ade80';

  // Pts display
  let ptsNum = 0;
  let ptsLabel = 'pts';
  if (isDone && hasPred && realHome != null) {
    const isExact = pred.l === realHome && pred.v === realAway;
    const signOk = Math.sign(pred.l - pred.v) === Math.sign(realHome - realAway);
    if (isExact) ptsNum = 3;
    else if (signOk) ptsNum = 1;
    if (pred.gol) ptsNum += 2; // simplified
    ptsLabel = 'pts';
  } else if (hasPred) {
    ptsNum = pred.gol ? 7 : 4;
    ptsLabel = 'máx';
  }

  return (
    <div className={`jc-card ${boostActive ? 'jc-boost' : ''} ${isLive ? 'jc-live' : ''}`} onClick={onClick} style={{ cursor: onClick ? 'pointer' : 'default' }}>
      <div className="jc-main">
        <div className="jc-stripe" style={{ background: gc }}></div>
        <div className="jc-body">
          <div className="jc-teams-row">
            <div className="jc-team">
              <div className="jc-flag"><img src={hFlag} alt="" onError={e => e.target.style.display='none'}/></div>
              <span className="jc-team-name">{match.home}</span>
            </div>
            <span className="jc-vs">vs</span>
            <div className="jc-team jc-team-away">
              <span className="jc-team-name">{match.away}</span>
              <div className="jc-flag"><img src={aFlag} alt="" onError={e => e.target.style.display='none'}/></div>
            </div>
          </div>
          <div className="jc-venue">
            <span>{match.stadium}</span>
            {isLive && <span className="jc-live-dot"></span>}
          </div>
          {hasPred && (
            <div className="jc-chips">
              <span className="jc-chip on">1×2</span>
              {pred.gol && <span className="jc-chip on">⚽</span>}
              {boostActive && <span className="jc-chip jc-chip-boost">🔥</span>}
            </div>
          )}
        </div>
        <div className="jc-score-wrap">
          {(isLive || isDone) && realHome != null ? (
            <React.Fragment>
              <span className={`jc-score ${isLive ? 'live' : 'has'}`}>{realHome}</span>
              <span className="jc-score-sep">–</span>
              <span className={`jc-score ${isLive ? 'live' : 'has'}`}>{realAway}</span>
            </React.Fragment>
          ) : hasPred ? (
            <React.Fragment>
              <span className="jc-score has">{pred.l}</span>
              <span className="jc-score-sep">–</span>
              <span className="jc-score has">{pred.v}</span>
            </React.Fragment>
          ) : (
            <React.Fragment>
              <span className="jc-score pending">–</span>
              <span className="jc-score-sep">–</span>
              <span className="jc-score pending">–</span>
            </React.Fragment>
          )}
        </div>
        <div className="jc-pts">
          <div className={`jc-pts-num ${hasPred ? (boostActive ? 'boost' : 'on') : 'pending'}`}>{ptsNum}</div>
          <div className="jc-pts-label">{ptsLabel}</div>
        </div>
      </div>
      {boostActive && (
        <div className="jc-boost-bar">
          <span>🔥</span>
          <span className="jc-boost-txt">Boost ×2</span>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { JCard });

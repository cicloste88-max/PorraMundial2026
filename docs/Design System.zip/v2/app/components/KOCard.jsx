// KOCard.jsx — Porra Mundial 2026 · v2
// Tarjeta KO (eliminatorias) · espejo de .ko-card cinematic

function KOCard({ matchId, home, away, homeSlug, awaySlug, homeFlag, awayFlag,
  venue, date, round, status = 'open', pred, realHome, realAway, onClick }) {

  const homeName = home || 'Por definir';
  const awayName = away || 'Por definir';
  const hFlag = homeFlag ? SB_URL + '/flags/' + homeFlag + '.png' : null;
  const aFlag = awayFlag ? SB_URL + '/flags/' + awayFlag + '.png' : null;
  const hKit = homeSlug ? kitUrl(homeSlug, 'home') : null;
  const aKit = awaySlug ? kitUrl(awaySlug, 'away') : null;
  const isLocked = status === 'locked' || status === 'pending';
  const isSaved = status === 'saved';
  const isGold = status === 'gold';
  const isDone = status === 'done';
  const isLive = status === 'live';
  const hasPred = pred && pred.l != null;

  const statusLabels = {
    open: { cls:'ko-st-open', label:'Abierta' },
    locked: { cls:'ko-st-locked', label:'Bloqueada' },
    pending: { cls:'ko-st-pending', label:'Pendiente' },
    saved: { cls:'ko-st-saved', label:'Guardada' },
    done: { cls:'ko-st-done', label:'Finalizado' },
    live: { cls:'ko-st-live', label:'En vivo' },
    gold: { cls:'ko-st-gold', label:'Final' },
  };
  const st = statusLabels[status] || statusLabels.open;

  return (
    <div className={`ko-card-v2 ${isLocked ? 'ko-locked' : ''} ${isSaved ? 'ko-saved' : ''} ${isGold ? 'ko-gold' : ''}`}
         onClick={() => !isLocked && onClick?.()} style={{ cursor: isLocked ? 'default' : 'pointer' }}>

      {/* Hero */}
      <div className="ko-hero-v2">
        <div className="ko-half-v2 ko-half-L">
          {hKit && <div className="ko-kit-v2" style={{ backgroundImage: `url('${hKit}')` }}></div>}
          <div className="ko-vign-v2 ko-vign-L"></div>
          <div className="ko-team-v2 ko-team-home">
            {hFlag && <div className="ko-flag-v2"><img src={hFlag} alt="" onError={e => e.target.style.display='none'}/></div>}
            <div className={`ko-tname-v2 ${!home ? 'tbd' : ''}`}>{homeName}</div>
            <div className="ko-trole-v2">local</div>
          </div>
        </div>
        <div className="ko-half-v2 ko-half-R">
          {aKit && <div className="ko-kit-v2" style={{ backgroundImage: `url('${aKit}')` }}></div>}
          <div className="ko-vign-v2 ko-vign-R"></div>
          <div className="ko-team-v2 ko-team-away">
            {aFlag && <div className="ko-flag-v2"><img src={aFlag} alt="" onError={e => e.target.style.display='none'}/></div>}
            <div className={`ko-tname-v2 ${!away ? 'tbd' : ''}`}>{awayName}</div>
            <div className="ko-trole-v2">visitante</div>
          </div>
        </div>
        <div className="ko-fade-v2"></div>
        {/* VS center */}
        <div className="ko-center-v2">
          <div className="ko-pill-v2">{round} · {venue || '—'}</div>
          <div className="ko-vs-v2">
            <div className="ko-ball-v2"></div>
            <span className="ko-vs-txt">VS</span>
          </div>
        </div>

        {/* Locked overlay */}
        {isLocked && (
          <div className="ko-locked-overlay-v2">
            <span className="ko-locked-icon-v2">🔒</span>
            <span className="ko-locked-label-v2">Completa la ronda anterior</span>
          </div>
        )}
      </div>

      {/* Score display (when saved/done/live) */}
      {hasPred && !isLocked && (
        <div className="ko-score-v2">
          <span className="ko-score-num-v2">{pred.l}</span>
          <span className="ko-score-sep-v2">–</span>
          <span className="ko-score-num-v2">{pred.v}</span>
          {pred.classifier && <span className="ko-classifier-v2">Clasifica: {pred.classifier}</span>}
        </div>
      )}

      {/* Footer */}
      <div className="ko-footer-v2">
        <span className="ko-date-v2">{date || '—'}</span>
        <span className={`ko-status-v2 ${st.cls}`}>{st.label}</span>
      </div>
    </div>
  );
}

Object.assign(window, { KOCard });

// DCard.jsx — Porra Mundial 2026 · v2
// Tarjeta Directo (live scores) · espejo de producción .dcard

function DCard({ match, pred, realHome, realAway, minute, status = 'notstarted', events = [], venue }) {
  const homeTeam = EQUIPOS.find(e => e.name === match.home);
  const awayTeam = EQUIPOS.find(e => e.name === match.away);
  if (!homeTeam || !awayTeam) return null;

  const hFlag = SB_URL + '/flags/' + homeTeam.flag + '.png';
  const aFlag = SB_URL + '/flags/' + awayTeam.flag + '.png';
  const hasPred = pred && pred.l !== null;
  const isLive = status === 'live' || status === 'halftime' || status === 'overtime' || status === 'penalties';
  const isFinal = status === 'final';
  const hasResult = realHome != null;

  // Status label
  const statusMap = {
    live: { cls: 'dc-pill-live', label: `EN VIVO ${minute}'` },
    halftime: { cls: 'dc-pill-half', label: 'DESCANSO' },
    overtime: { cls: 'dc-pill-ot', label: 'PRÓRROGA' },
    penalties: { cls: 'dc-pill-pen', label: 'PENALTIS' },
    final: { cls: 'dc-pill-final', label: 'FINALIZADO' },
    notstarted: { cls: 'dc-pill-ns', label: 'POR JUGAR' },
  };
  const st = statusMap[status] || statusMap.notstarted;

  // Pts live calc (simplified)
  let ptsLive = 0;
  if (hasPred && hasResult) {
    const isExact = pred.l === realHome && pred.v === realAway;
    const signOk = Math.sign(pred.l - pred.v) === Math.sign(realHome - realAway);
    if (isExact) ptsLive = 3;
    else if (signOk) ptsLive = 1;
  }

  return (
    <div className={`dc-card ${isLive ? 'dc-is-live' : ''} ${isFinal ? 'dc-is-final' : ''}`}>
      <div className="dc-main">
        <div className="dc-stripe" style={{ background: isLive ? 'var(--red)' : isFinal ? 'var(--text-3)' : 'var(--green)' }}></div>
        <div className="dc-body">
          <div className="dc-teams-row">
            <div className="dc-team">
              <div className="dc-flag"><img src={hFlag} alt="" onError={e => e.target.style.display='none'}/></div>
              <span className="dc-team-name">{match.home}</span>
            </div>
            <div className="dc-score-wrap">
              {hasResult ? (
                <React.Fragment>
                  <span className={`dc-score ${isLive ? 'live' : ''}`}>{realHome}</span>
                  <span className="dc-score-sep">–</span>
                  <span className={`dc-score ${isLive ? 'live' : ''}`}>{realAway}</span>
                </React.Fragment>
              ) : (
                <React.Fragment>
                  <span className="dc-score pending">–</span>
                  <span className="dc-score-sep">:</span>
                  <span className="dc-score pending">–</span>
                </React.Fragment>
              )}
            </div>
            <div className="dc-team dc-team-away">
              <span className="dc-team-name">{match.away}</span>
              <div className="dc-flag"><img src={aFlag} alt="" onError={e => e.target.style.display='none'}/></div>
            </div>
          </div>

          {/* Status + venue */}
          <div className="dc-status">
            <span className={`dc-status-pill ${st.cls}`}>
              {isLive && <span className="dc-live-dot"></span>}
              {st.label}
            </span>
            <span className="dc-sep">·</span>
            <span>{venue || match.stadium}</span>
          </div>

          {/* Events */}
          {events.length > 0 && (
            <div className="dc-events">
              {events.map((ev, i) => (
                <div key={i} className={`dc-event ${ev.type === 'own-goal' ? 'own-goal' : ''}`}>
                  <span className="dc-evt-icon">{ev.type === 'goal' ? '⚽' : ev.type === 'red-card' ? '🟥' : '🟨'}</span>
                  <span className="dc-evt-min">{ev.minute}'</span>
                  <span className="dc-evt-player">{ev.player}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pred + pts */}
        {hasPred && (
          <div className="dc-pred">
            <div className="dc-pred-label">Tu pred</div>
            <div className={`dc-pred-score ${!hasResult ? 'pending' : ''}`}>{pred.l}–{pred.v}</div>
            {hasResult && (
              <div className={`dc-pts-live ${ptsLive > 0 ? 'won' : 'zero'}`}>
                {ptsLive > 0 ? `+${ptsLive}` : '0'} pts
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { DCard });

// screens.jsx — Pantallas FIFA WC 2026

// ─────────────────────────────────────────────────────────────
// HOME — Dashboard
// ─────────────────────────────────────────────────────────────
function ScreenHome({ cardStyle = 'A', density = 'cozy' }) {
  return (
    <div className={`fc-screen density-${density}`}>
      {/* Hero */}
      <div className="fc-hero-bg" style={{ paddingTop: 56 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: 22 }}>
          <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
            <img src="assets/logo-26.webp" alt="FIFA 26" style={{ height: 36, width:'auto' }}/>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, letterSpacing:'0.12em', color:'rgba(255,255,255,0.6)' }}>
              CAN · MEX · USA
            </div>
          </div>
          <div style={{ display:'flex', gap: 8 }}>
            <button style={btnGhost}><Icon name="search" size={18} color="#fff"/></button>
            <button style={btnGhost}><Icon name="bell" size={18} color="#fff"/></button>
          </div>
        </div>

        {/* Featured live */}
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom: 12 }}>
          <span className="fc-live-dot"></span>
          <span style={{ fontFamily:'var(--font-display)', fontSize:11, fontWeight:700, letterSpacing:'0.14em', color:'#fff' }}>EN VIVO · GRUPO A</span>
        </div>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: 18 }}>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:8 }}>
            <Flag code="MEX" size="xl"/>
            <div style={{ fontFamily:'var(--font-display)', fontSize:14, fontWeight:700 }}>MEX</div>
          </div>
          <div style={{ textAlign:'center' }}>
            <div className="score" style={{ fontSize: 56, color:'#fff', lineHeight: 1 }}>
              2<span style={{ color:'rgba(255,255,255,0.25)', margin:'0 12px' }}>−</span>1
            </div>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, letterSpacing:'0.1em', color:'var(--fifa-red)', marginTop: 6 }}>
              67' · 2T
            </div>
          </div>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:8 }}>
            <Flag code="ARG" size="xl"/>
            <div style={{ fontFamily:'var(--font-display)', fontSize:14, fontWeight:700 }}>ARG</div>
          </div>
        </div>

        {/* Hero meta */}
        <div style={{ display:'flex', justifyContent:'center', gap: 16, fontSize: 11, color:'rgba(255,255,255,0.6)', marginBottom: 14 }}>
          <span>Estadio Azteca</span>
          <span>·</span>
          <span>Ciudad de México</span>
        </div>

        <button style={{
          width: '100%', padding: '13px 16px', borderRadius: 12,
          background: '#fff', color: 'var(--ink-900)', border: 'none',
          fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 700, letterSpacing:'0.04em', textTransform: 'uppercase',
          display:'flex', alignItems:'center', justifyContent:'center', gap: 8,
        }}>
          <Icon name="tv" size={16}/> VER EN VIVO
        </button>
      </div>

      {/* Body */}
      <div className="fc-scroll" style={{ paddingBottom: 12 }}>

        {/* Próximos */}
        <div className="fc-section-title">
          <h3>Próximos partidos</h3>
          <a>Calendario</a>
        </div>
        <div style={{ padding: '0 18px', display:'flex', flexDirection:'column', gap: 10 }}>
          <MatchCard style={cardStyle} home="ESP" away="BRA" when="HOY · 20:00" status="upcoming" venue="MetLife Stadium · NJ"/>
          <MatchCard style={cardStyle} home="FRA" away="GER" when="MAÑ · 14:00" status="upcoming" venue="Estadio Azteca · CDMX"/>
          <MatchCard style={cardStyle} home="USA" away="POR" hs={null} as={null} when="JUE · 18:30" status="upcoming" venue="SoFi Stadium · LA"/>
        </div>

        {/* Standings teaser */}
        <div className="fc-section-title">
          <h3>Grupo A</h3>
          <a>Tabla completa</a>
        </div>
        <div style={{ padding: '0 18px' }}>
          <StandingsMini/>
        </div>

        <div style={{ height: 12 }}/>
      </div>

      <BottomTabs active="home"/>
    </div>
  );
}

const btnGhost = {
  width: 36, height: 36, borderRadius: '50%',
  background: 'rgba(255,255,255,0.12)', border: 'none',
  display:'flex', alignItems:'center', justifyContent:'center',
  backdropFilter:'blur(20px)', WebkitBackdropFilter:'blur(20px)',
  cursor:'pointer',
};

function PredictionTile() {
  return (
    <div style={{
      background: 'linear-gradient(135deg, #FFF8E1 0%, #FFEDB3 100%)',
      borderRadius: 16, padding: '14px 16px',
      border: '1px solid rgba(201,169,97,0.3)',
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ position:'absolute', right: -10, top: -10, opacity: 0.18 }}>
        <Icon name="trophy" size={88} color="#9A7B3A"/>
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom: 10 }}>
        <div>
          <div className="fc-eyebrow" style={{ color:'#9A7B3A' }}>PREDICTOR · NIVEL 12</div>
          <div style={{ fontFamily:'var(--font-display)', fontSize: 22, fontWeight: 800, color:'var(--ink-900)' }}>
            <span className="fc-num">2,847</span> <span style={{ fontSize: 13, fontWeight:600, color:'#9A7B3A' }}>pts</span>
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize: 11, color:'#9A7B3A', fontWeight:600 }}>Posición</div>
          <div style={{ fontFamily:'var(--font-display)', fontSize: 17, fontWeight:700, color:'var(--ink-900)' }}>#412 <span style={{ color:'var(--win)', fontSize: 11 }}>↑18</span></div>
        </div>
      </div>
      <div style={{ display:'flex', alignItems:'center', gap: 10, fontSize: 12, color:'var(--ink-700)', borderTop:'1px solid rgba(201,169,97,0.3)', paddingTop: 10 }}>
        <Icon name="flame" size={14} color="#E30613"/>
        <span><b>3 predicciones</b> pendientes para hoy</span>
        <Icon name="chev-r" size={14} color="rgba(0,0,0,0.4)"/>
      </div>
    </div>
  );
}

function StandingsMini() {
  const teams = [
    { code:'MEX', pj:2, pts:6, gd:'+3' },
    { code:'ARG', pj:2, pts:3, gd:'+1' },
    { code:'KOR', pj:2, pts:3, gd:'-1' },
    { code:'AUS', pj:2, pts:0, gd:'-3' },
  ];
  return (
    <div style={{ background:'#fff', borderRadius: 16, border:'1px solid var(--ink-200)', overflow:'hidden' }}>
      <div style={{ display:'grid', gridTemplateColumns:'auto 1fr 30px 30px 30px 36px', gap: 10, padding:'10px 14px', background:'var(--ink-50)', fontSize: 10, fontFamily:'var(--font-display)', fontWeight:700, letterSpacing:'0.06em', color:'var(--ink-400)', textTransform:'uppercase' }}>
        <span>#</span><span>Equipo</span><span style={{ textAlign:'center' }}>PJ</span><span style={{ textAlign:'center' }}>DG</span><span style={{ textAlign:'center' }}></span><span style={{ textAlign:'center' }}>PTS</span>
      </div>
      {teams.map((t, i) => (
        <div key={t.code} style={{ display:'grid', gridTemplateColumns:'auto 1fr 30px 30px 30px 36px', gap: 10, padding:'12px 14px', alignItems:'center', borderTop: i===0 ? 'none' : '1px solid var(--ink-100)' }}>
          <span className="fc-num" style={{ fontWeight:700, color: i<2?'var(--win)':'var(--ink-400)' }}>{i+1}</span>
          <div style={{ display:'flex', alignItems:'center', gap: 8 }}>
            <Flag code={t.code}/>
            <span style={{ fontWeight:600, fontSize: 13 }}>{C_NAMES[t.code]}</span>
          </div>
          <span className="fc-num" style={{ textAlign:'center', fontSize: 12, color:'var(--ink-500)' }}>{t.pj}</span>
          <span className="fc-num" style={{ textAlign:'center', fontSize: 12, color:'var(--ink-500)' }}>{t.gd}</span>
          <span/>
          <span className="fc-num" style={{ textAlign:'center', fontSize: 14, fontWeight:700 }}>{t.pts}</span>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// PREDICCIONES
// ─────────────────────────────────────────────────────────────
function ScreenPredictions({ cardStyle = 'A', density = 'cozy' }) {
  return (
    <div className={`fc-screen density-${density}`}>
      <div style={{ paddingTop: 56, padding: '56px 18px 0' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 18 }}>
          <span className="fc-eyebrow">PREDICTOR</span>
          <div style={{ display:'flex', gap: 8 }}>
            <button style={{...btnGhost, background:'var(--ink-100)'}}><Icon name="trophy" size={18} color="var(--ink-700)"/></button>
          </div>
        </div>
        <h1 style={{ fontFamily:'var(--font-display)', fontSize: 30, fontWeight:800, letterSpacing:'-0.02em', margin:'0 0 4px', color:'var(--ink-900)' }}>
          Tus predicciones
        </h1>
        <div style={{ fontSize: 14, color:'var(--ink-500)' }}>Jornada 3 · Fase de grupos</div>

        {/* Resumen — copa de oro */}
        <div style={{ marginTop: 18 }}>
          <PredictionTile/>
        </div>

        {/* Stats strip */}
        <div style={{
          marginTop: 12, display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 1,
          background:'var(--ink-200)', borderRadius: 14, overflow:'hidden',
        }}>
          {[
            { label:'Puntos', value:'2,847', accent:'var(--ink-900)' },
            { label:'Aciertos', value:'68%', accent:'var(--win)' },
            { label:'Racha', value:'7', accent:'var(--fifa-red)', icon:'flame' },
          ].map((s, i) => (
            <div key={i} style={{ background:'#fff', padding:'12px 14px' }}>
              <div style={{ fontSize: 10, fontFamily:'var(--font-display)', fontWeight:700, letterSpacing:'0.08em', color:'var(--ink-400)', textTransform:'uppercase' }}>{s.label}</div>
              <div style={{ display:'flex', alignItems:'center', gap: 4, marginTop: 4 }}>
                <span className="fc-num" style={{ fontFamily:'var(--font-display)', fontSize: 22, fontWeight:800, color: s.accent, letterSpacing:'-0.02em' }}>{s.value}</span>
                {s.icon && <Icon name={s.icon} size={14} color={s.accent}/>}
              </div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div style={{ display:'flex', gap: 8, marginTop: 18, marginBottom: 14, overflowX:'auto', scrollbarWidth:'none' }}>
          {['Por jugar', 'Hoy · 3', 'Esta sem.', 'Resueltas'].map((f, i) => (
            <button key={f} style={{
              padding: '7px 14px', borderRadius: 999,
              background: i===0 ? 'var(--ink-900)' : 'var(--ink-100)',
              color: i===0 ? '#fff' : 'var(--ink-700)',
              border: 'none',
              fontFamily:'var(--font-display)', fontSize: 12, fontWeight:600,
              whiteSpace:'nowrap', cursor:'pointer',
            }}>{f}</button>
          ))}
        </div>
      </div>

      <div className="fc-scroll" style={{ padding: '0 18px 12px' }}>
        <div className="fc-eyebrow" style={{ marginTop: 8, marginBottom: 10 }}>HOY · CIERRA EN 4H 22M</div>
        <PredictionCard home="ESP" away="BRA" when="20:00" closesIn="4h 22m" status="open" my={{ h:2, a:1 }}/>
        <div style={{ height: 10 }}/>
        <PredictionCard home="FRA" away="GER" when="22:30" closesIn="6h 52m" status="open" my={{ h:1, a:1 }}/>
        <div style={{ height: 10 }}/>
        <PredictionCard home="USA" away="POR" when="MAÑ 18:30" closesIn="—" status="locked" my={null}/>

        <div className="fc-eyebrow" style={{ marginTop: 22, marginBottom: 10 }}>RESUELTAS</div>
        <PredictionCard home="MEX" away="ARG" when="DOM" status="resolved" my={{ h:2, a:1 }} actual={{ h:2, a:1 }} pts={50}/>
        <div style={{ height: 10 }}/>
        <PredictionCard home="ENG" away="ITA" when="DOM" status="resolved" my={{ h:1, a:0 }} actual={{ h:2, a:2 }} pts={0}/>

        <div style={{ height: 16 }}/>
      </div>

      <BottomTabs active="pred"/>
    </div>
  );
}

function PredictionCard({ home, away, when, closesIn, status, my, actual, pts }) {
  const isResolved = status === 'resolved';
  const isLocked = status === 'locked';
  const isOpen = status === 'open';
  const correct = isResolved && my && actual && my.h === actual.h && my.a === actual.a;

  return (
    <div style={{
      background: '#fff',
      borderRadius: 18,
      border: `1px solid ${correct ? 'rgba(0,131,74,0.3)' : 'var(--ink-200)'}`,
      padding: 14,
      position:'relative', overflow:'hidden',
    }}>
      {correct && <div style={{ position:'absolute', top:0, left:0, right:0, height: 3, background:'var(--win)' }}/>}

      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 12 }}>
        <span className="fc-eyebrow">{when}</span>
        {isOpen && <span className="pred-chip" style={{ background:'#E8F1FF', color:'var(--fifa-blue)' }}>Cierra · {closesIn}</span>}
        {isLocked && <span className="pred-chip" style={{ background:'var(--ink-100)', color:'var(--ink-500)' }}><Icon name="lock" size={11} stroke={2.2}/> Bloqueada</span>}
        {isResolved && (
          <span className="pred-chip" style={{ background: correct?'rgba(0,131,74,0.1)':'var(--ink-100)', color: correct?'var(--win)':'var(--ink-500)' }}>
            {correct ? `+${pts} pts` : `${pts} pts`}
          </span>
        )}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr auto 1fr', alignItems:'center', gap: 12, marginBottom: isOpen ? 14 : 0 }}>
        <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
          <Flag code={home} size="lg"/>
          <div style={{ fontWeight:700, fontSize: 14 }}>{home}</div>
        </div>
        <div style={{ textAlign:'center' }}>
          {my ? (
            <div className="score" style={{ fontSize: 24, color: isResolved ? (correct?'var(--win)':'var(--ink-400)') : 'var(--ink-900)' }}>
              {my.h}<span style={{ color:'var(--ink-300)', margin:'0 6px' }}>:</span>{my.a}
            </div>
          ) : (
            <div className="fc-eyebrow" style={{ fontSize: 11 }}>—</div>
          )}
          {isResolved && actual && (
            <div style={{ fontSize: 10, color:'var(--ink-400)', marginTop: 2 }}>
              Real: <span className="fc-num" style={{ fontWeight:600 }}>{actual.h}–{actual.a}</span>
            </div>
          )}
        </div>
        <div style={{ display:'flex', alignItems:'center', gap: 10, justifyContent:'flex-end' }}>
          <div style={{ fontWeight:700, fontSize: 14 }}>{away}</div>
          <Flag code={away} size="lg"/>
        </div>
      </div>

      {isOpen && (
        <div>
          {/* Stepper rows */}
          <div style={{ background:'var(--ink-50)', borderRadius: 12, padding: 10, display:'flex', flexDirection:'column', gap: 8 }}>
            <ScoreStepper code={home} value={my.h}/>
            <ScoreStepper code={away} value={my.a}/>
          </div>
          <div style={{ display:'flex', gap: 8, marginTop: 10, fontSize: 11, color:'var(--ink-500)' }}>
            <span>Ganador exacto: <b style={{ color:'var(--ink-700)' }}>+50</b></span>
            <span>·</span>
            <span>Resultado: <b style={{ color:'var(--ink-700)' }}>+30</b></span>
            <span>·</span>
            <span>1×2: <b style={{ color:'var(--ink-700)' }}>+10</b></span>
          </div>
        </div>
      )}
    </div>
  );
}

function ScoreStepper({ code, value }) {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'auto 1fr auto auto auto', alignItems:'center', gap: 10 }}>
      <Flag code={code}/>
      <span style={{ fontWeight:600, fontSize: 13 }}>{C_NAMES[code]}</span>
      <button style={stepBtn}><Icon name="minus" size={14} color="var(--ink-500)"/></button>
      <span className="fc-num" style={{ fontFamily:'var(--font-display)', fontSize: 18, fontWeight:700, minWidth: 18, textAlign:'center' }}>{value}</span>
      <button style={stepBtn}><Icon name="plus" size={14} color="var(--ink-500)"/></button>
    </div>
  );
}

const stepBtn = {
  width: 26, height: 26, borderRadius: '50%',
  background: '#fff', border: '1px solid var(--ink-200)',
  display:'flex', alignItems:'center', justifyContent:'center',
  cursor:'pointer', padding: 0,
};

// ─────────────────────────────────────────────────────────────
// LIVE — Match detail
// ─────────────────────────────────────────────────────────────
function ScreenLive({ cardStyle = 'A', density = 'cozy' }) {
  return (
    <div className={`fc-screen dark density-${density}`}>
      {/* Hero */}
      <div style={{
        paddingTop: 56, padding:'56px 18px 0',
        background: 'linear-gradient(180deg, #0A0E1A 0%, #1A2138 100%)',
        position:'relative', overflow:'hidden',
      }}>
        <div style={{ position:'absolute', right:-60, top:0, width: 280, height: 280, borderRadius:'50%', background:'radial-gradient(circle, rgba(201,169,97,0.12) 0%, transparent 70%)' }}/>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 18 }}>
          <button style={btnGhost}><Icon name="chev-r" size={18} color="#fff" stroke={2.4}/></button>
          <div style={{ display:'flex', alignItems:'center', gap: 6 }}>
            <span className="fc-live-dot"></span>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, letterSpacing:'0.12em', color:'#fff' }}>EN VIVO · 67'</span>
          </div>
          <button style={btnGhost}><Icon name="bell" size={18} color="#fff"/></button>
        </div>

        <div className="fc-eyebrow" style={{ color:'rgba(255,255,255,0.5)', textAlign:'center', marginBottom: 4 }}>GRUPO A · J3</div>
        <div style={{ fontSize: 11, color:'rgba(255,255,255,0.4)', textAlign:'center', marginBottom: 18 }}>Estadio Azteca · CDMX</div>

        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', position:'relative' }}>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 8, width: 90 }}>
            <Flag code="MEX" size="xl"/>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 14, fontWeight:700, color:'#fff' }}>MÉXICO</div>
            <div style={{ display:'flex', gap: 3 }}>
              <span className="dot" style={{ background:'var(--win)' }}/>
              <span className="dot" style={{ background:'var(--win)' }}/>
              <span className="dot" style={{ background:'var(--draw)' }}/>
            </div>
          </div>
          <div style={{ flex:1, textAlign:'center' }}>
            <div className="score" style={{ fontSize: 64, color:'#fff', lineHeight: 1, fontWeight: 800 }}>
              2<span style={{ color:'rgba(255,255,255,0.2)', margin:'0 14px' }}>−</span>1
            </div>
          </div>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 8, width: 90 }}>
            <Flag code="ARG" size="xl"/>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 14, fontWeight:700, color:'#fff' }}>ARGENTINA</div>
            <div style={{ display:'flex', gap: 3 }}>
              <span className="dot" style={{ background:'var(--win)' }}/>
              <span className="dot" style={{ background:'var(--draw)' }}/>
              <span className="dot" style={{ background:'var(--loss)' }}/>
            </div>
          </div>
        </div>

        {/* Goal scorers */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 18, marginTop: 22, paddingTop: 14, borderTop:'1px solid rgba(255,255,255,0.1)' }}>
          <div style={{ fontSize: 11, color:'rgba(255,255,255,0.7)', lineHeight: 1.7 }}>
            <div>⚽ Lozano <span style={{ color:'rgba(255,255,255,0.4)' }}>23'</span></div>
            <div>⚽ Giménez <span style={{ color:'rgba(255,255,255,0.4)' }}>54'</span></div>
          </div>
          <div style={{ fontSize: 11, color:'rgba(255,255,255,0.7)', lineHeight: 1.7, textAlign:'right' }}>
            <div><span style={{ color:'rgba(255,255,255,0.4)' }}>61'</span> Álvarez ⚽</div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', gap: 22, marginTop: 22, borderBottom:'1px solid rgba(255,255,255,0.1)' }}>
          {['Stats','Eventos','Alineaciones','XG'].map((t, i) => (
            <div key={t} style={{
              paddingBottom: 12, fontFamily:'var(--font-display)',
              fontSize: 12, fontWeight: 600, letterSpacing:'0.04em',
              color: i===0 ? '#fff' : 'rgba(255,255,255,0.5)',
              borderBottom: i===0 ? '2px solid var(--fifa-gold)' : '2px solid transparent',
              marginBottom: -1, textTransform:'uppercase',
            }}>{t}</div>
          ))}
        </div>
      </div>

      <div className="fc-scroll" style={{ padding:'18px 18px 12px', background: 'var(--ink-900)' }}>
        {/* Possession bar */}
        <StatRow label="Posesión" home="58%" away="42%" hVal={58} aVal={42}/>
        <StatRow label="Tiros" home="11" away="8" hVal={11} aVal={8}/>
        <StatRow label="Tiros a puerta" home="5" away="3" hVal={5} aVal={3}/>
        <StatRow label="Córners" home="4" away="6" hVal={4} aVal={6}/>
        <StatRow label="Faltas" home="9" away="13" hVal={9} aVal={13}/>
        <StatRow label="Pases completados" home="412" away="298" hVal={412} aVal={298}/>
        <StatRow label="xG" home="1.84" away="1.21" hVal={1.84} aVal={1.21}/>

        <div style={{ marginTop: 16, padding: 14, borderRadius: 14, background:'var(--ink-800)', border:'1px solid var(--ink-700)' }}>
          <div className="fc-eyebrow" style={{ color:'rgba(255,255,255,0.5)', marginBottom: 8 }}>TU PREDICCIÓN</div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div className="score" style={{ fontSize: 22, color:'#fff' }}>2<span style={{ margin:'0 8px', color:'rgba(255,255,255,0.3)' }}>:</span>1</div>
            <span className="pred-chip" style={{ background:'rgba(0,131,74,0.15)', color:'#4DD49B' }}>Vas ganando · +50 pts</span>
          </div>
        </div>

        <div style={{ height: 16 }}/>
      </div>

      <BottomTabs active="live" dark/>
    </div>
  );
}

function StatRow({ label, home, away, hVal, aVal }) {
  const tot = hVal + aVal;
  const hPct = (hVal/tot)*100;
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom: 6, fontSize: 12 }}>
        <span className="fc-num" style={{ color:'#fff', fontWeight:700 }}>{home}</span>
        <span style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:600, letterSpacing:'0.04em', color:'rgba(255,255,255,0.5)', textTransform:'uppercase' }}>{label}</span>
        <span className="fc-num" style={{ color:'#fff', fontWeight:700 }}>{away}</span>
      </div>
      <div style={{ display:'flex', height: 4, borderRadius: 999, overflow:'hidden', background:'rgba(255,255,255,0.08)' }}>
        <div style={{ width: `${hPct}%`, background:'var(--fifa-gold)' }}/>
        <div style={{ flex: 1, background:'rgba(255,255,255,0.25)' }}/>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Bottom tab bar
// ─────────────────────────────────────────────────────────────
function BottomTabs({ active='grupos', dark=false }) {
  const tabs = [
    { id:'grupos',  label:'Grupos',  icon:'trophy' },
    { id:'jornada', label:'Jornada', icon:'cal' },
    { id:'directo', label:'Directo', icon:'live' },
    { id:'pred',    label:'Predictor', icon:'pred' },
    { id:'profile', label:'Perfil',  icon:'profile' },
  ];
  return (
    <div className="fc-tabbar">
      {tabs.map(t => (
        <div key={t.id} className={`fc-tab ${active===t.id?'active':''}`}>
          <Icon name={t.icon} size={22} stroke={active===t.id?2.2:1.8}/>
          <span className="fc-tab-label">{t.label}</span>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { ScreenHome, ScreenPredictions, ScreenLive, BottomTabs, PredictionCard });

// screens-v3.jsx — Quiniela completa: header simplificado + stepper + Eliminatorias + Bracket usuario + Cuadro oficial + Premios

// ── Header simplificado ───────────────────────────────────────
function PorraHeader({ points = 32, subtitle = '', onPremios, onCuadro, activeAction = null }) {
  return (
    <div style={{ padding: '50px 16px 0' }}>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap: 12 }}>
        <button style={{
          background:'#1F2433', border:'1px solid #2A3142', color:'rgba(255,255,255,0.85)',
          borderRadius: 8, padding:'7px 11px', fontSize: 12, fontWeight:600,
          display:'flex', alignItems:'center', gap: 4, cursor:'pointer',
        }}>← Inicio</button>
        <div style={{ flex: 1, textAlign:'right' }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'flex-end', gap: 6 }}>
            <Icon name="trophy" size={18} color="#22C55E"/>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 22, fontWeight:800, color:'#fff', letterSpacing:'-0.01em' }}>Porra</span>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 22, fontWeight:800, color:'#22C55E', letterSpacing:'-0.01em' }}>Mundial 2026</span>
          </div>
          {subtitle && <div style={{ fontSize: 11.5, color:'rgba(255,255,255,0.5)', marginTop: 2 }}>{subtitle}</div>}
        </div>
      </div>

      {/* Acciones contextuales: Cuadro oficial + Premios */}
      <div style={{ display:'flex', gap: 8, marginTop: 14 }}>
        <button style={{
          background: activeAction==='cuadro'?'rgba(96,165,250,0.18)':'rgba(96,165,250,0.08)',
          border:`1px solid ${activeAction==='cuadro'?'#60A5FA':'rgba(96,165,250,0.3)'}`,
          color:'#60A5FA',
          borderRadius: 9, padding:'9px 12px', fontSize: 12, fontWeight:700, fontFamily:'var(--font-display)',
          display:'flex', alignItems:'center', gap: 7, cursor:'pointer', flex:1, justifyContent:'center',
        }}>
          <Icon name="trophy" size={13} color="#60A5FA"/> Cuadro oficial
        </button>
        <button style={{
          background: activeAction==='premios'?'rgba(255,215,0,0.18)':'rgba(255,215,0,0.08)',
          border:`1px solid ${activeAction==='premios'?'#FFD700':'rgba(255,215,0,0.35)'}`,
          color:'#FFD700',
          borderRadius: 9, padding:'9px 12px', fontSize: 12, fontWeight:700, fontFamily:'var(--font-display)',
          display:'flex', alignItems:'center', gap: 7, cursor:'pointer', flex:1, justifyContent:'center',
        }}>
          <span style={{ fontSize: 12 }}>★</span> Premios
        </button>
      </div>

      <div style={{ marginTop: 12, display:'flex', alignItems:'center', gap: 14, fontSize: 12, color:'rgba(255,255,255,0.6)' }}>
        <span>Puntos: <span style={{ fontFamily:'var(--font-display)', fontSize: 18, fontWeight:800, color:'#22C55E' }}>{points}</span></span>
        <span style={{ width: 4, height: 4, borderRadius: 999, background:'rgba(255,255,255,0.2)' }}/>
        <span style={{ display:'flex', alignItems:'center', gap: 5 }}>
          <span style={{ width: 18, height: 18, borderRadius:'50%', background:'#7C3AED', color:'#fff', fontSize: 9, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center' }}>C</span>
          ADMIN
        </span>
      </div>
    </div>
  );
}

// ── Stepper de fases ──────────────────────────────────────────
function PhaseStepper({ active = 'grupos', progress = {} }) {
  // progress: { grupos: {done, total}, ko16: {done, total}, ... }
  const phases = [
    { id:'grupos', label:'Grupos', total: 72 },
    { id:'ko16',   label:'1/16',   total: 16 },
    { id:'ko8',    label:'1/8',    total: 8  },
    { id:'ko4',    label:'1/4',    total: 4  },
    { id:'sf',     label:'Semis',  total: 2  },
    { id:'final',  label:'Final',  total: 2  }, // incluye 3º/4º
  ];

  let unlocked = true; // grupos siempre unlocked
  return (
    <div style={{ padding:'10px 12px 0' }}>
      <div style={{ display:'flex', alignItems:'stretch', gap: 4 }}>
        {phases.map((p, i) => {
          const prev = phases[i-1];
          const prevDone = prev ? (progress[prev.id]?.done ?? 0) >= prev.total : true;
          if (i > 0 && !prevDone) unlocked = false;
          const phaseProg = progress[p.id] || { done: 0, total: p.total };
          const isComplete = phaseProg.done >= p.total;
          const isActive = p.id === active;
          const isLocked = !unlocked && !isComplete;
          const accent = isComplete ? '#22C55E' : isActive ? '#FFD700' : isLocked ? 'rgba(255,255,255,0.2)' : '#fff';

          return (
            <React.Fragment key={p.id}>
              <div style={{
                flex: isActive?1.4:1, minWidth: 0,
                background: isActive?'#1F2433':'#0E1320',
                border:`1px solid ${isActive?'#FFD700':isComplete?'rgba(34,197,94,0.3)':'#1F2433'}`,
                borderRadius: 8, padding:'7px 4px', textAlign:'center',
                opacity: isLocked?0.5:1, cursor: isLocked?'not-allowed':'pointer',
                position:'relative',
              }}>
                <div style={{ fontFamily:'var(--font-display)', fontSize: 10, fontWeight:700, color: accent, letterSpacing:'0.04em', display:'flex', alignItems:'center', justifyContent:'center', gap: 3 }}>
                  {isLocked && <Icon name="lock" size={9} color="rgba(255,255,255,0.4)"/>}
                  {p.label}
                </div>
                <div style={{ fontSize: 9, color:'rgba(255,255,255,0.55)', marginTop: 1, fontFamily:'var(--font-display)' }}>
                  {isLocked ? '—' : `${phaseProg.done}/${p.total}`}
                </div>
                {isActive && <div style={{ position:'absolute', bottom:-1, left: '20%', right:'20%', height: 2, background:'#FFD700', borderRadius: 2 }}/>}
              </div>
              {i < phases.length-1 && (
                <div style={{ alignSelf:'center', color:'rgba(255,255,255,0.25)', fontSize: 10 }}>›</div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

// ── Tarjeta de pronóstico compacta ────────────────────────────
function MiniPredCard({ data, current=false }) {
  return (
    <div style={{
      background:'#0E1320', border:`1px solid ${current?'rgba(227,6,19,0.45)':'#2A3142'}`,
      borderRadius: 14, overflow:'hidden',
      transform: current?'scale(1)':'scale(0.92)',
      opacity: current?1:0.55,
      transition:'all 0.3s ease',
      flexShrink: 0, width: 240,
    }}>
      <div style={{ position:'relative', height: 96, display:'grid', gridTemplateColumns:'1fr 1fr' }}>
        <div style={{ position:'relative', overflow:'hidden', background: data.homeColors?.[0] || '#1F2433' }}>
          <JerseyBg colors={data.homeColors || ['#1F2433','#0E1320']} side="left"/>
        </div>
        <div style={{ position:'relative', overflow:'hidden', background: data.awayColors?.[0] || '#1F2433' }}>
          <JerseyBg colors={data.awayColors || ['#1F2433','#0E1320']} side="right"/>
        </div>
        <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', gap: 6 }}>
          <Flag code={data.home}/>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:800, color:'#fff', textShadow:'0 1px 3px rgba(0,0,0,0.7)' }}>VS</span>
          <Flag code={data.away}/>
        </div>
      </div>
      <div style={{ padding:'10px 12px' }}>
        <div style={{ display:'flex', justifyContent:'center', alignItems:'center', gap: 12, marginBottom: 8 }}>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 22, fontWeight:800, color:'#fff' }}>{data.h ?? '—'}</span>
          <span style={{ color:'rgba(255,255,255,0.3)' }}>:</span>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 22, fontWeight:800, color:'#fff' }}>{data.a ?? '—'}</span>
        </div>
        <div style={{ fontSize: 10, color:'rgba(255,255,255,0.55)', textAlign:'center' }}>
          {data.stadium}
        </div>
      </div>
    </div>
  );
}

// ── Fila de fase comprimida ───────────────────────────────────
function PhaseRow({ phase, expanded, onToggle }) {
  const accent = phase.locked ? 'rgba(255,255,255,0.2)' : phase.done >= phase.total ? '#22C55E' : '#FFD700';
  return (
    <div onClick={() => !phase.locked && onToggle()} style={{
      marginBottom: 10,
      cursor: phase.locked?'not-allowed':'pointer',
      opacity: phase.locked?0.5:1,
    }}>
      <div style={{
        display:'flex', alignItems:'center', gap: 12,
        padding:'14px 14px', borderRadius: 12,
        background: expanded ? '#0E1320' : 'transparent',
        border:`1px solid ${expanded ? accent : 'transparent'}`,
      }}>
        <div style={{ width: 4, height: 44, borderRadius: 2, background: accent }}/>
        <div style={{ display:'flex', flexDirection:'column', minWidth: 0 }}>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 10, fontWeight:700, letterSpacing:'0.1em', color:'rgba(255,255,255,0.55)', textTransform:'uppercase' }}>{phase.shortLabel}</span>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 22, fontWeight:800, color:'#fff', letterSpacing:'-0.01em', lineHeight: 1.05 }}>{phase.label}</span>
          <span style={{ fontSize: 10, color:'rgba(255,255,255,0.45)', marginTop: 2 }}>{phase.total} {phase.total===1?'partido':'partidos'}</span>
        </div>
        <div style={{ flex: 1 }}/>
        {phase.locked ? (
          <div style={{ display:'flex', alignItems:'center', gap: 5, color:'rgba(255,255,255,0.45)' }}>
            <Icon name="lock" size={13} color="rgba(255,255,255,0.45)"/>
            <span style={{ fontSize: 10, fontWeight:700, fontFamily:'var(--font-display)', letterSpacing:'0.06em' }}>BLOQUEADO</span>
          </div>
        ) : (
          <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-end', gap: 3 }}>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, color: accent }}>
              {phase.done}/{phase.total}
            </span>
            <div style={{ width: 60, height: 3, borderRadius: 2, background:'rgba(255,255,255,0.08)', overflow:'hidden' }}>
              <div style={{ height:'100%', width:`${(phase.done/phase.total)*100}%`, background: accent }}/>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function PhaseExpanded({ phase, onCollapse }) {
  const accent = phase.done >= phase.total ? '#22C55E' : '#FFD700';
  return (
    <div style={{ background:'#0A0E1A', border:`1px solid ${accent}`, borderRadius: 14, padding:'14px 0 18px', marginBottom: 10 }}>
      <div onClick={onCollapse} style={{ display:'flex', alignItems:'center', gap: 10, padding:'0 14px', marginBottom: 12, cursor:'pointer' }}>
        <span style={{ fontFamily:'var(--font-display)', fontSize: 20, fontWeight:800, color:'#fff' }}>{phase.label}</span>
        <span style={{ fontSize: 11, color:'rgba(255,255,255,0.5)' }}>· 1/{phase.total}</span>
        <div style={{ flex:1 }}/>
        <button style={{
          background:'rgba(124,58,237,0.15)', border:'1px solid rgba(124,58,237,0.4)', color:'#A78BFA',
          borderRadius: 7, padding:'5px 10px', fontSize: 10, fontWeight:700, fontFamily:'var(--font-display)',
          cursor:'pointer', display:'flex', alignItems:'center', gap: 4,
        }}>
          🎲 Simular
        </button>
      </div>

      <div style={{ position:'relative' }}>
        <button style={{
          position:'absolute', left: 6, top:'50%', transform:'translateY(-50%) rotate(180deg)', zIndex: 2,
          width: 30, height: 30, borderRadius:'50%', background:'rgba(0,0,0,0.7)', backdropFilter:'blur(10px)',
          border:'1px solid rgba(255,255,255,0.1)', display:'flex', alignItems:'center', justifyContent:'center',
          cursor:'pointer', padding:0,
        }}>
          <Icon name="chev-r" size={13} color="#fff" stroke={2.4}/>
        </button>
        <button style={{
          position:'absolute', right: 6, top:'50%', transform:'translateY(-50%)', zIndex: 2,
          width: 30, height: 30, borderRadius:'50%', background:'rgba(0,0,0,0.7)', backdropFilter:'blur(10px)',
          border:'1px solid rgba(255,255,255,0.1)', display:'flex', alignItems:'center', justifyContent:'center',
          cursor:'pointer', padding:0,
        }}>
          <Icon name="chev-r" size={13} color="#fff" stroke={2.4}/>
        </button>

        <div style={{ display:'flex', gap: 10, overflowX:'auto', padding:'0 40px', scrollbarWidth:'none' }}>
          {(phase.fixtures || []).map((f, i) => <MiniPredCard key={i} data={f} current={i===0}/>)}
        </div>
      </div>

      <div style={{ display:'flex', justifyContent:'center', gap: 5, marginTop: 12 }}>
        {Array.from({ length: phase.total }).map((_, i) => (
          <span key={i} style={{ width: i===0?16:5, height: 5, borderRadius: 999, background: i===0?accent:'rgba(255,255,255,0.2)' }}/>
        ))}
      </div>
    </div>
  );
}

// ── Pantalla GRUPOS (vista comprimida) ──────────────────────
function GroupRow({ letter, complete=true, expanded=false, onToggle, progress }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div onClick={onToggle} style={{
        display:'flex', alignItems:'center', gap: 12,
        padding:'12px 14px', borderRadius: 12,
        background: expanded ? '#0E1320' : 'transparent',
        border:`1px solid ${expanded ? '#22C55E' : 'transparent'}`,
        cursor:'pointer',
      }}>
        <div style={{ width: 4, height: 36, borderRadius: 2, background: complete?'#22C55E':'rgba(255,255,255,0.2)' }}/>
        <div style={{ display:'flex', flexDirection:'column' }}>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:600, letterSpacing:'0.08em', color:'rgba(255,255,255,0.55)', textTransform:'uppercase' }}>Grupo</span>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 26, fontWeight:800, color:'#fff', letterSpacing:'-0.02em', lineHeight: 1 }}>{letter}</span>
        </div>
        <button style={{
          background:'rgba(124,58,237,0.15)', border:'1px solid rgba(124,58,237,0.4)', color:'#A78BFA',
          borderRadius: 7, padding:'5px 10px', fontSize: 11, fontWeight:700, fontFamily:'var(--font-display)',
          display:'flex', alignItems:'center', gap: 5, cursor:'pointer',
        }}>
          <span>🎲</span> Simular
        </button>
        <div style={{ flex: 1, height: 3, borderRadius: 2, background:'rgba(255,255,255,0.1)', overflow:'hidden' }}>
          <div style={{ height:'100%', width: complete?'100%':'50%', background:'#22C55E' }}/>
        </div>
        <span style={{ fontSize: 11, color:'rgba(255,255,255,0.5)', fontFamily:'var(--font-display)', fontWeight:600 }}>
          {complete ? '6/6' : `${progress||3}/6`}
        </span>
      </div>
    </div>
  );
}

function GroupExpanded({ letter, fixtures, currentIdx=0 }) {
  return (
    <div style={{ background:'#0A0E1A', border:'1px solid #22C55E', borderRadius: 14, padding:'14px 0 18px', marginBottom: 10 }}>
      <div style={{ display:'flex', alignItems:'center', gap: 10, padding:'0 14px', marginBottom: 12 }}>
        <span style={{ fontFamily:'var(--font-display)', fontSize: 20, fontWeight:800, color:'#fff' }}>Grupo {letter}</span>
        <span style={{ fontSize: 11, color:'rgba(255,255,255,0.5)' }}>· {currentIdx+1}/{fixtures.length}</span>
        <div style={{ flex:1 }}/>
        <span style={{ fontFamily:'var(--font-display)', fontSize: 10, fontWeight:700, color:'#22C55E', letterSpacing:'0.06em' }}>COMPLETO ✓</span>
      </div>

      <div style={{ position:'relative' }}>
        <div style={{ display:'flex', gap: 10, overflowX:'auto', padding:'0 16px', scrollbarWidth:'none' }}>
          {fixtures.map((f, i) => <MiniPredCard key={i} data={f} current={i===currentIdx}/>)}
        </div>
      </div>

      <div style={{ display:'flex', justifyContent:'center', gap: 5, marginTop: 12 }}>
        {fixtures.map((_, i) => (
          <span key={i} style={{ width: i===currentIdx?16:5, height: 5, borderRadius: 999, background: i===currentIdx?'#22C55E':'rgba(255,255,255,0.2)' }}/>
        ))}
      </div>

      <div style={{ margin:'14px 14px 0', padding: 10, background:'#0E1320', borderRadius: 10, border:'1px solid #1F2433' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 8 }}>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 10, fontWeight:700, color:'rgba(255,255,255,0.5)', letterSpacing:'0.08em' }}>CLASIFICACIÓN PROYECTADA</span>
          <span style={{ fontSize: 10, color:'#22C55E', fontWeight:600 }}>Ver →</span>
        </div>
        {[
          { code:'MEX', pts:9 },
          { code:'RSA', pts:6 },
          { code:'KOR', pts:3 },
          { code:'CZE', pts:0 },
        ].map((t, i) => (
          <div key={t.code} style={{ display:'grid', gridTemplateColumns:'auto auto 1fr auto', gap: 8, alignItems:'center', padding:'5px 0', borderTop: i===0?'none':'1px solid rgba(255,255,255,0.05)' }}>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 12, fontWeight:700, color: i<2?'#22C55E':'rgba(255,255,255,0.4)', width: 14 }}>{i+1}</span>
            <Flag code={t.code}/>
            <span style={{ fontSize: 12, color:'#fff', fontWeight:600 }}>{C_NAMES[t.code]}</span>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 13, fontWeight:700, color:'#fff' }}>{t.pts}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ScreenGruposComprimido({ density='cozy' }) {
  const [expanded, setExpanded] = React.useState('A');
  const sampleFix = [
    { home:'MEX', away:'RSA', h:2, a:1, stadium:'Estadio Azteca · CDMX', homeColors:['#006847','#CE1126'], awayColors:['#007749','#FFB81C'] },
    { home:'KOR', away:'CZE', h:0, a:2, stadium:'Estadio Akron · Guadalajara', homeColors:['#CD2E3A','#fff'], awayColors:['#fff','#11457E'] },
    { home:'MEX', away:'KOR', h:1, a:0, stadium:'Estadio BBVA · Monterrey', homeColors:['#006847','#CE1126'], awayColors:['#CD2E3A','#fff'] },
    { home:'RSA', away:'CZE', h:1, a:1, stadium:'Estadio Azteca · CDMX', homeColors:['#007749','#FFB81C'], awayColors:['#fff','#11457E'] },
    { home:'MEX', away:'CZE', h:3, a:0, stadium:'Estadio Akron · Guadalajara', homeColors:['#006847','#CE1126'], awayColors:['#fff','#11457E'] },
    { home:'KOR', away:'RSA', h:2, a:2, stadium:'Estadio BBVA · Monterrey', homeColors:['#CD2E3A','#fff'], awayColors:['#007749','#FFB81C'] },
  ];

  return (
    <div className={`fc-screen dark density-${density}`} style={{ background:'#0A0E1A' }}>
      <PorraHeader points={32} subtitle="Quiniela · Fase de grupos"/>
      <PhaseStepper active="grupos" progress={{
        grupos:{done:72,total:72}, ko16:{done:0,total:16}, ko8:{done:0,total:8}, ko4:{done:0,total:4}, sf:{done:0,total:2}, final:{done:0,total:2},
      }}/>

      <div style={{ padding:'14px 16px 6px' }}>
        <div style={{
          background:'rgba(124,58,237,0.08)', border:'1px solid rgba(124,58,237,0.25)', borderRadius: 10,
          padding:'10px 12px', display:'flex', alignItems:'center', gap: 10,
        }}>
          <span style={{ fontSize: 13 }}>🎲</span>
          <span style={{ fontSize: 12, color:'rgba(255,255,255,0.85)', flex:1 }}>Simular al azar:</span>
          <button style={{
            background:'rgba(124,58,237,0.2)', border:'1px solid rgba(124,58,237,0.5)', color:'#A78BFA',
            borderRadius: 7, padding:'5px 10px', fontSize: 11, fontWeight:700, fontFamily:'var(--font-display)',
            cursor:'pointer',
          }}>
            Todos los grupos (72)
          </button>
        </div>
      </div>

      <div className="fc-scroll" style={{ padding:'10px 12px 12px' }}>
        {['A','B','C','D','E','F','G','H'].map(L => (
          L === expanded
            ? <GroupExpanded key={L} letter={L} fixtures={sampleFix} currentIdx={0}/>
            : <GroupRow key={L} letter={L} complete={true} progress={6} expanded={false} onToggle={()=>setExpanded(L)}/>
        ))}
        <div style={{ height: 8 }}/>
      </div>

      <BottomTabs active="grupos" dark/>
    </div>
  );
}

// ── Pantalla ELIMINATORIAS (5 fases comprimidas + 3º/4º) ────
function ScreenEliminatorias({ density='cozy' }) {
  const [expanded, setExpanded] = React.useState('ko16');
  const ko16Fix = [
    { home:'MEX', away:'NED', h:2, a:1, stadium:'1A vs 2B · MetLife NJ', homeColors:['#006847','#CE1126'], awayColors:['#FF6700','#003DA5'] },
    { home:'ARG', away:'POR', h:1, a:1, stadium:'1B vs 2A · SoFi Los Ángeles', homeColors:['#74ACDF','#fff'], awayColors:['#006600','#FF0000'] },
    { home:'ESP', away:'JPN', h:3, a:0, stadium:'1C vs 2D · BMO Toronto', homeColors:['#AA151B','#F1BF00'], awayColors:['#fff','#BC002D'] },
    { home:'FRA', away:'CRO', h:2, a:0, stadium:'1D vs 2C · Estadio Azteca', homeColors:['#0055A4','#fff'], awayColors:['#FF0000','#fff'] },
  ];

  const phases = [
    { id:'ko16',  shortLabel:'1/16',  label:'16avos de final', total: 16, done: 16, fixtures: ko16Fix, locked:false },
    { id:'ko8',   shortLabel:'1/8',   label:'Octavos',         total: 8,  done: 8,  fixtures: ko16Fix.slice(0,2), locked:false },
    { id:'ko4',   shortLabel:'1/4',   label:'Cuartos',         total: 4,  done: 2,  fixtures: ko16Fix.slice(0,2), locked:false },
    { id:'sf',    shortLabel:'SF',    label:'Semifinales',     total: 2,  done: 0,  fixtures: [], locked:true },
    { id:'3rd',   shortLabel:'3º/4º', label:'Final consolación', total: 1, done: 0, fixtures: [], locked:true, isThird:true },
    { id:'final', shortLabel:'F',     label:'Final',           total: 1,  done: 0,  fixtures: [], locked:true },
  ];

  return (
    <div className={`fc-screen dark density-${density}`} style={{ background:'#0A0E1A' }}>
      <PorraHeader points={32} subtitle="Quiniela · Fase eliminatoria"/>
      <PhaseStepper active="ko16" progress={{
        grupos:{done:72,total:72}, ko16:{done:16,total:16}, ko8:{done:8,total:8}, ko4:{done:2,total:4}, sf:{done:0,total:2}, final:{done:0,total:2},
      }}/>

      <div className="fc-scroll" style={{ padding:'14px 12px 12px' }}>
        {phases.map(p => (
          p.id === expanded && !p.locked
            ? <PhaseExpanded key={p.id} phase={p} onCollapse={()=>setExpanded(null)}/>
            : <PhaseRow key={p.id} phase={p} expanded={false} onToggle={()=>setExpanded(p.id)}/>
        ))}
        <div style={{ height: 8 }}/>
      </div>

      <BottomTabs active="grupos" dark/>
    </div>
  );
}

// ── BRACKET (mi cuadro vs cuadro oficial) ────────────────────
function BMatch({ h, a, hs, as, winner, gold=false, official=false }) {
  const showScore = hs != null && as != null;
  return (
    <div style={{
      background: gold?'rgba(255,215,0,0.08)':'#0E1320',
      border:`1px solid ${gold?'#FFD700':'#1F2433'}`,
      borderRadius: 6, padding:'4px 5px',
      display:'flex', flexDirection:'column', gap: 2,
    }}>
      <div style={{ display:'flex', alignItems:'center', gap: 4, opacity: !winner||winner===h?1:0.45 }}>
        <span style={{ fontSize: 12 }}>{h ? FLAGS[h] : '·'}</span>
        <span style={{ fontSize: 9, fontWeight:700, fontFamily:'var(--font-display)', color:'#fff', flex:1 }}>{h || '—'}</span>
        <span className="fc-num" style={{ fontSize: 10, fontWeight:700, color:gold?'#FFD700':'#fff' }}>{showScore?hs:'–'}</span>
      </div>
      <div style={{ display:'flex', alignItems:'center', gap: 4, opacity: !winner||winner===a?1:0.45 }}>
        <span style={{ fontSize: 12 }}>{a ? FLAGS[a] : '·'}</span>
        <span style={{ fontSize: 9, fontWeight:700, fontFamily:'var(--font-display)', color:'#fff', flex:1 }}>{a || '—'}</span>
        <span className="fc-num" style={{ fontSize: 10, fontWeight:700, color:gold?'#FFD700':'#fff' }}>{showScore?as:'–'}</span>
      </div>
    </div>
  );
}

function BracketBody({ data, mode='mine' }) {
  // mode: 'mine' (con picks completos) | 'official' (sólo realidad, partidos no jugados con —)
  return (
    <div style={{ padding:'0 0 14px' }}>
      <div style={{ padding:'0 16px', display:'flex', justifyContent:'space-between', marginBottom: 10 }}>
        {['1/16','1/8','SF','FINAL','SF','1/8','1/16'].map((l,i) => (
          <span key={i} style={{ fontFamily:'var(--font-display)', fontSize: 9, fontWeight:700, letterSpacing:'0.1em', color: l==='FINAL'?'#FFD700':'rgba(255,255,255,0.5)' }}>{l}</span>
        ))}
      </div>

      <div style={{ padding:'0 12px', display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1.4fr 1fr 1fr 1fr', gap: 4, alignItems:'center' }}>
        {/* Left side */}
        <div style={{ display:'flex', flexDirection:'column', gap: 4 }}>
          {data.left16.map((m, i) => <BMatch key={i} {...m}/>)}
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap: 28 }}>
          {data.left8.map((m, i) => <BMatch key={i} {...m}/>)}
        </div>
        <div style={{ display:'flex' }}>
          <BMatch {...data.leftSF}/>
        </div>
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 6 }}>
          <span style={{ fontSize: 22 }}>🏆</span>
          <BMatch {...data.final} gold/>
          {/* 3º/4º */}
          <div style={{ marginTop: 10, padding:'4px 6px', background:'rgba(205,127,50,0.08)', border:'1px solid rgba(205,127,50,0.4)', borderRadius: 6, width:'100%' }}>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 8, fontWeight:700, color:'#CD7F32', letterSpacing:'0.1em', textAlign:'center', marginBottom: 3 }}>3º/4º</div>
            <BMatch {...data.third}/>
          </div>
        </div>
        <div style={{ display:'flex' }}>
          <BMatch {...data.rightSF}/>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap: 28 }}>
          {data.right8.map((m, i) => <BMatch key={i} {...m}/>)}
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap: 4 }}>
          {data.right16.map((m, i) => <BMatch key={i} {...m}/>)}
        </div>
      </div>
    </div>
  );
}

const myBracket = {
  left16:  [{h:'MEX',a:'NED',hs:2,as:1,winner:'MEX'},{h:'ESP',a:'JPN',hs:3,as:0,winner:'ESP'},{h:'BRA',a:'SEN',hs:2,as:0,winner:'BRA'},{h:'POR',a:'MAR',hs:2,as:1,winner:'POR'},{h:'ITA',a:'AUS',hs:1,as:0,winner:'ITA'},{h:'NED',a:'CRO',hs:2,as:1,winner:'NED'},{h:'COL',a:'KOR',hs:1,as:0,winner:'COL'},{h:'BEL',a:'CHI',hs:2,as:0,winner:'BEL'}],
  left8:   [{h:'MEX',a:'ESP',hs:1,as:2,winner:'ESP'},{h:'BRA',a:'POR',hs:1,as:2,winner:'POR'}],
  leftSF:  {h:'ESP',a:'POR',hs:2,as:0,winner:'ESP'},
  final:   {h:'ESP',a:'ARG',hs:3,as:2,winner:'ESP'},
  third:   {h:'POR',a:'FRA',hs:2,as:1,winner:'POR'},
  rightSF: {h:'ARG',a:'FRA',hs:1,as:0,winner:'ARG'},
  right8:  [{h:'ARG',a:'GER',hs:2,as:1,winner:'ARG'},{h:'FRA',a:'ENG',hs:2,as:1,winner:'FRA'}],
  right16: [{h:'ARG',a:'POL',hs:1,as:0,winner:'ARG'},{h:'GER',a:'URU',hs:2,as:1,winner:'GER'},{h:'FRA',a:'BEL',hs:1,as:0,winner:'FRA'},{h:'ENG',a:'CRO',hs:2,as:0,winner:'ENG'},{h:'USA',a:'CAN',hs:1,as:0,winner:'USA'},{h:'SUI',a:'NOR',hs:0,as:1,winner:'NOR'},{h:'DEN',a:'TUR',hs:2,as:1,winner:'DEN'},{h:'EGY',a:'NGA',hs:1,as:2,winner:'NGA'}],
};

const officialBracket = {
  left16:  [{h:'MEX',a:'NED',hs:1,as:2,winner:'NED'},{h:'ESP',a:'JPN',hs:2,as:0,winner:'ESP'},{h:'BRA',a:'SEN',hs:3,as:0,winner:'BRA'},{h:'POR',a:'MAR',hs:1,as:0,winner:'POR'},{h:'ITA',a:'AUS',hs:2,as:0,winner:'ITA'},{h:'NED',a:'CRO',hs:1,as:1,winner:'CRO'},{h:'COL',a:'KOR',hs:2,as:1,winner:'COL'},{h:'BEL',a:'CHI'}],
  left8:   [{h:'NED',a:'ESP',hs:0,as:2,winner:'ESP'},{h:'BRA',a:'POR'}],
  leftSF:  {h:'ESP',a:null},
  final:   {h:null,a:null},
  third:   {h:null,a:null},
  rightSF: {h:null,a:null},
  right8:  [{h:'ARG',a:'GER'},{h:'FRA',a:'ENG'}],
  right16: [{h:'ARG',a:'POL',hs:1,as:1,winner:'ARG'},{h:'GER',a:'URU',hs:2,as:0,winner:'GER'},{h:'FRA',a:'BEL'},{h:'ENG',a:'CRO'},{h:'USA',a:'CAN'},{h:'SUI',a:'NOR'},{h:'DEN',a:'TUR'},{h:'EGY',a:'NGA'}],
};

function ScreenBracketMine({ density='cozy' }) {
  return (
    <div className="fc-screen dark" style={{ background:'#0A0E1A' }}>
      <PorraHeader points={32} subtitle="Tu cuadro completo" activeAction="cuadro"/>

      <div style={{ padding:'14px 16px 4px' }}>
        <div style={{ display:'flex', gap: 6, padding: 4, background:'#0E1320', borderRadius: 10, border:'1px solid #1F2433' }}>
          {[
            { id:'mine', label:'Mi cuadro', active:true },
            { id:'official', label:'Cuadro oficial' },
          ].map(t => (
            <div key={t.id} style={{
              flex: 1, padding:'8px 6px', borderRadius: 7, textAlign:'center',
              background: t.active ? '#1F2433' : 'transparent',
              color: t.active ? '#fff' : 'rgba(255,255,255,0.5)',
              fontSize: 12, fontWeight:600, fontFamily:'var(--font-display)',
            }}>{t.label}</div>
          ))}
        </div>
      </div>

      <div className="fc-scroll" style={{ padding:'10px 0 12px' }}>
        <div style={{ padding:'0 16px', marginBottom: 10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <span style={{ fontSize: 11, color:'rgba(255,255,255,0.55)' }}>Tus picks · 32 partidos previstos</span>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 12, fontWeight:700, color:'#22C55E' }}>+{180} pts proyectados</span>
        </div>
        <BracketBody data={myBracket} mode="mine"/>
      </div>

      <BottomTabs active="grupos" dark/>
    </div>
  );
}

function ScreenBracketOfficial({ density='cozy' }) {
  return (
    <div className="fc-screen dark" style={{ background:'#0A0E1A' }}>
      <PorraHeader points={32} subtitle="Cuadro oficial del torneo" activeAction="cuadro"/>

      <div style={{ padding:'14px 16px 4px' }}>
        <div style={{ display:'flex', gap: 6, padding: 4, background:'#0E1320', borderRadius: 10, border:'1px solid #1F2433' }}>
          {[
            { id:'mine', label:'Mi cuadro' },
            { id:'official', label:'Cuadro oficial', active:true },
          ].map(t => (
            <div key={t.id} style={{
              flex: 1, padding:'8px 6px', borderRadius: 7, textAlign:'center',
              background: t.active ? '#1F2433' : 'transparent',
              color: t.active ? '#fff' : 'rgba(255,255,255,0.5)',
              fontSize: 12, fontWeight:600, fontFamily:'var(--font-display)',
            }}>{t.label}</div>
          ))}
        </div>
      </div>

      <div className="fc-scroll" style={{ padding:'10px 0 12px' }}>
        <div style={{ padding:'0 16px', marginBottom: 10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <span style={{ display:'flex', alignItems:'center', gap: 6, fontSize: 11, color:'rgba(255,255,255,0.55)' }}>
            <span className="fc-live-dot"/> En curso · Cuartos
          </span>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, color:'#60A5FA' }}>11/32 jugados</span>
        </div>
        <BracketBody data={officialBracket} mode="official"/>

        {/* Comparativa con tu cuadro */}
        <div style={{ margin:'4px 16px 0', padding:'10px 12px', background:'#0E1320', border:'1px solid #1F2433', borderRadius: 10 }}>
          <div style={{ fontFamily:'var(--font-display)', fontSize: 10, fontWeight:700, color:'rgba(255,255,255,0.55)', letterSpacing:'0.1em', marginBottom: 8 }}>VS TU CUADRO</div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 8 }}>
            {[
              { l:'Aciertos', v:'8', c:'#22C55E' },
              { l:'Fallos',   v:'3', c:'#FF6B6B' },
              { l:'Puntos',   v:'+45', c:'#FFD700' },
            ].map(s => (
              <div key={s.l} style={{ textAlign:'center' }}>
                <div style={{ fontFamily:'var(--font-display)', fontSize: 18, fontWeight:800, color: s.c }}>{s.v}</div>
                <div style={{ fontSize: 10, color:'rgba(255,255,255,0.5)' }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <BottomTabs active="grupos" dark/>
    </div>
  );
}

// ── PREMIOS (rediseño según mock del usuario) ────────────────
function ChampionHero({ logo='26', country='CANADA', countryName='Canadá', flag='CAN', date='19 jul · MetLife Stadium, Nueva York' }) {
  return (
    <div style={{
      background:'#0E1320', border:'1px solid #1F2433', borderRadius: 16,
      padding:'18px 16px', position:'relative', overflow:'hidden',
    }}>
      {/* Glow gold */}
      <div style={{ position:'absolute', top:-40, right:-40, width: 140, height: 140, borderRadius:'50%', background:'radial-gradient(circle, rgba(255,215,0,0.18), transparent 70%)' }}/>

      <div style={{ display:'grid', gridTemplateColumns:'auto auto 1fr', gap: 14, alignItems:'center', position:'relative' }}>
        {/* Logo "26" */}
        <div style={{
          width: 70, height: 70, borderRadius: 12, background:'#fff',
          display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
          boxShadow:'0 4px 16px rgba(0,0,0,0.4)',
        }}>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 28, fontWeight:900, color:'#0A0E1A', letterSpacing:'-0.04em', lineHeight: 0.9 }}>{logo}</span>
          <span style={{ fontFamily:'var(--font-display)', fontSize: 7, fontWeight:800, color:'#0A0E1A', letterSpacing:'0.1em', marginTop: 2 }}>FIFA</span>
        </div>

        {/* Escudo país (placeholder con bandera enmarcada) */}
        <div style={{
          width: 70, height: 70, borderRadius:'50%', background:'#fff',
          display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column',
          border:'3px solid #fff', boxShadow:'0 4px 16px rgba(0,0,0,0.4)',
          fontSize: 36,
        }}>
          {FLAGS[flag] || '🏆'}
          <span style={{ fontFamily:'var(--font-display)', fontSize: 7, fontWeight:800, color:'#0A0E1A', letterSpacing:'0.06em', marginTop:-2 }}>{country}</span>
        </div>

        {/* Texto campeón */}
        <div style={{ minWidth: 0 }}>
          <div style={{ display:'flex', alignItems:'center', gap: 5, marginBottom: 4 }}>
            <span style={{ color:'#FFD700', fontSize: 11 }}>★</span>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 9, fontWeight:700, color:'#FFD700', letterSpacing:'0.14em' }}>CAMPEÓN<br/>DEL MUNDO</span>
          </div>
          <div style={{ fontFamily:'var(--font-display)', fontSize: 24, fontWeight:800, color:'#fff', lineHeight: 1, letterSpacing:'-0.02em', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{countryName}</div>
          <div style={{ fontSize: 9, color:'rgba(255,255,255,0.5)', marginTop: 4, lineHeight: 1.3, fontStyle:'italic' }}>FIFA World Cup 2026</div>
          <div style={{ fontSize: 10, color:'rgba(255,255,255,0.6)', marginTop: 3, lineHeight: 1.3 }}>{date}</div>
        </div>
      </div>
    </div>
  );
}

function AwardCard({ category, player, country, photoBg, highlighted=false }) {
  // photoBg: gradiente o color base. En producción reemplazar por <img> con src de Supabase
  return (
    <div style={{
      position:'relative', borderRadius: 12, overflow:'hidden', height: 160,
      border: highlighted ? '2px solid #FFD700' : '1px solid #1F2433',
      background: photoBg,
    }}>
      {/* Placeholder photo: gradient with player silhouette glyph */}
      <div style={{
        position:'absolute', inset: 0,
        background: photoBg,
      }}/>
      <div style={{
        position:'absolute', inset: 0,
        background:'radial-gradient(ellipse at 60% 30%, rgba(255,255,255,0.08), transparent 60%), linear-gradient(180deg, transparent 30%, rgba(0,0,0,0.85) 100%)',
      }}/>
      {/* Silueta jugador (placeholder) */}
      <div style={{ position:'absolute', top:'15%', left:'50%', transform:'translateX(-50%)', fontSize: 60, opacity: 0.3 }}>👤</div>

      <div style={{ position:'absolute', top: 8, left: 10, fontFamily:'var(--font-display)', fontSize: 8, fontWeight:700, color:'rgba(255,255,255,0.85)', letterSpacing:'0.14em' }}>
        {category}
      </div>

      <div style={{ position:'absolute', bottom: 10, left: 10, right: 10 }}>
        <div style={{ fontFamily:'var(--font-display)', fontSize: 14, fontWeight:800, color:'#fff', lineHeight: 1.05, letterSpacing:'-0.01em' }}>{player}</div>
        <div style={{ display:'flex', alignItems:'center', gap: 5, marginTop: 4 }}>
          <Flag code={country}/>
          <span style={{ fontSize: 10, color:'rgba(255,255,255,0.85)' }}>{C_NAMES[country] || country}</span>
        </div>
      </div>
    </div>
  );
}

function ScreenPremios({ density='cozy' }) {
  return (
    <div className="fc-screen dark" style={{ background:'#0A0E1A' }}>
      <PorraHeader points={32} subtitle="Cuadro de honor y premios individuales" activeAction="premios"/>

      <div className="fc-scroll" style={{ padding:'14px 16px 12px' }}>

        {/* Hero campeón */}
        <ChampionHero logo="26" country="CANADA" countryName="Canadá" flag="CAN" date="19 jul · MetLife Stadium, Nueva York"/>

        <div style={{ height: 14 }}/>

        {/* Premios individuales */}
        <div style={{
          background:'#0E1320', border:'1px solid #1F2433', borderRadius: 16,
          padding:'14px 14px',
        }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: 12, gap: 8 }}>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{ fontFamily:'var(--font-display)', fontSize: 18, fontWeight:800, color:'#fff', lineHeight: 1, letterSpacing:'-0.01em' }}>Premios<br/>Individuales</div>
              <div style={{ fontSize: 9, color:'rgba(255,255,255,0.5)', letterSpacing:'0.12em', marginTop: 4, fontFamily:'var(--font-display)' }}>COPA MUNDIAL 2026</div>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap: 6 }}>
              <span style={{
                background:'rgba(34,197,94,0.18)', border:'1px solid rgba(34,197,94,0.4)', color:'#22C55E',
                borderRadius: 6, padding:'4px 8px', fontSize: 11, fontWeight:800, fontFamily:'var(--font-display)', whiteSpace:'nowrap', textAlign:'center',
              }}>+65 pts</span>
              <span style={{
                background:'rgba(255,140,0,0.1)', border:'1px solid rgba(255,140,0,0.4)', color:'#FF8C00',
                borderRadius: 6, padding:'4px 8px', fontSize: 9, fontWeight:700, fontFamily:'var(--font-display)', whiteSpace:'nowrap', textAlign:'center',
              }}>Cierra antes<br/>de la final</span>
            </div>
          </div>

          {/* Grid 2x2 */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 8 }}>
            <AwardCard category="BALÓN DE ORO" player="Lamine Yamal" country="ESP" photoBg="linear-gradient(180deg, #5C2D2A 0%, #1A0F0E 100%)" highlighted/>
            <AwardCard category="BOTA DE ORO" player="Julián Álvarez" country="ARG" photoBg="linear-gradient(180deg, #1F4E2C 0%, #0A1F12 100%)"/>
            <AwardCard category="GUANTE DE ORO" player="E. Martínez" country="ARG" photoBg="linear-gradient(180deg, #2A2A3E 0%, #0E0E1A 100%)"/>
            <AwardCard category="MEJOR JOVEN S21" player="Honest Ahanor" country="NGA" photoBg="linear-gradient(180deg, #3A2A1F 0%, #1A0E0E 100%)"/>
          </div>

          {/* Footer: dots progreso + acciones */}
          <div style={{ display:'flex', alignItems:'center', gap: 8, marginTop: 14 }}>
            <div style={{ display:'flex', gap: 4 }}>
              {[1,2,3,4].map(i => <span key={i} style={{ width: 6, height: 6, borderRadius:'50%', background:'#22C55E' }}/>)}
            </div>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, color:'rgba(255,255,255,0.7)' }}>4/4 premios</span>
            <div style={{ flex: 1 }}/>
            <button style={{
              background:'rgba(34,197,94,0.18)', border:'1px solid rgba(34,197,94,0.4)', color:'#22C55E',
              borderRadius: 7, padding:'6px 11px', fontSize: 11, fontWeight:700, fontFamily:'var(--font-display)',
              display:'flex', alignItems:'center', gap: 5, cursor:'pointer',
            }}>✓ Guardado</button>
            <button style={{
              background:'transparent', border:'1px solid #2A3142', color:'rgba(255,255,255,0.7)',
              borderRadius: 7, padding:'6px 11px', fontSize: 11, fontWeight:600, fontFamily:'var(--font-display)',
              display:'flex', alignItems:'center', gap: 5, cursor:'pointer',
            }}>↩ Deshacer</button>
          </div>
        </div>

        <div style={{ height: 14 }}/>

        {/* Clasificación final */}
        <div style={{
          background:'#0E1320', border:'1px solid #1F2433', borderRadius: 16,
          padding:'14px 14px',
        }}>
          <div style={{ fontFamily:'var(--font-display)', fontSize: 10, fontWeight:700, color:'rgba(255,255,255,0.5)', letterSpacing:'0.16em', marginBottom: 12 }}>CLASIFICACIÓN FINAL</div>

          {[
            { pos: 2, code:'GER', name:'Alemania', label:'2.º Clasificado', medal:'silver' },
            { pos: 3, code:'BEL', name:'Bélgica', label:'3.er Clasificado', medal:'bronze' },
            { pos: 4, code:'ENG', name:'Inglaterra', label:'4.º Clasificado', medal:null },
          ].map((t, i) => (
            <div key={t.pos} style={{ display:'flex', alignItems:'center', gap: 12, padding:'10px 0', borderTop: i===0?'none':'1px solid rgba(255,255,255,0.06)' }}>
              {/* Medalla / posición */}
              <Medal pos={t.pos} type={t.medal}/>
              {/* Escudo país */}
              <div style={{
                width: 36, height: 36, borderRadius:'50%', background:'#fff',
                display:'flex', alignItems:'center', justifyContent:'center', fontSize: 18,
                border:'2px solid #fff',
              }}>
                {FLAGS[t.code]}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily:'var(--font-display)', fontSize: 18, fontWeight:800, color:'#fff', lineHeight: 1, letterSpacing:'-0.01em' }}>{t.name}</div>
                <div style={{ fontSize: 11, color:'rgba(255,255,255,0.5)', marginTop: 3 }}>{t.label}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ height: 12 }}/>
      </div>

      <BottomTabs active="grupos" dark/>
    </div>
  );
}

function Medal({ pos, type }) {
  if (type === 'silver') {
    return (
      <div style={{ width: 38, height: 38, borderRadius:'50%', background:'linear-gradient(135deg, #E8E8E8 0%, #A8A8A8 100%)', border:'2px solid #C0C0C0', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 2px 8px rgba(192,192,192,0.3)' }}>
        <span style={{ fontFamily:'var(--font-display)', fontSize: 16, fontWeight:900, color:'#fff', textShadow:'0 1px 2px rgba(0,0,0,0.4)' }}>2</span>
      </div>
    );
  }
  if (type === 'bronze') {
    return (
      <div style={{ width: 38, height: 38, borderRadius:'50%', background:'linear-gradient(135deg, #E8A87C 0%, #B8682E 100%)', border:'2px solid #CD7F32', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 2px 8px rgba(205,127,50,0.3)' }}>
        <span style={{ fontFamily:'var(--font-display)', fontSize: 16, fontWeight:900, color:'#fff', textShadow:'0 1px 2px rgba(0,0,0,0.4)' }}>3</span>
      </div>
    );
  }
  return (
    <div style={{ width: 38, height: 38, borderRadius: 8, background:'#1F2A4A', border:'1px solid #2A3142', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <span style={{ fontFamily:'var(--font-display)', fontSize: 16, fontWeight:900, color:'#60A5FA' }}>{pos}</span>
    </div>
  );
}

Object.assign(window, {
  ScreenGruposComprimido, ScreenEliminatorias,
  ScreenBracketMine, ScreenBracketOfficial, ScreenPremios,
});

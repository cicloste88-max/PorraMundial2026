// screens-v2.jsx — Pantallas Grupos / Jornada / Directo

// ── Datos de ejemplo ─────────────────────────────────────────
const GROUP_FIXTURES = [
  { id:1, home:'MEX', away:'RSA', stadium:'Estadio Ciudad de México', closesIn:'43d 11h', boost:2,
    goalScorer:'9 · Raúl Jiménez', aiPred:'1 · Local (78%)',
    aiText:'México en casa contra Sudáfrica: la IA ha visto cosas más sorprendentes, pero no muchas.',
    homeColors:['#006847','#CE1126'], awayColors:['#007749','#FFB81C'], pts:6, saved:true },
  { id:2, home:'KOR', away:'CZE', stadium:'Estadio Guadalajara', closesIn:'43d 18h', boost:null,
    goalScorer:'11 · Adam Hložek', aiPred:'1 · Local (39%)',
    aiText:'Corea del Sur gana porque alguien tiene que ganar y ellos tienen mejor ELO, qué novedad.',
    homeColors:['#CD2E3A','#FFFFFF'], awayColors:['#FFFFFF','#11457E'], pts:7, saved:true },
  { id:3, home:'POR', away:'JPN', stadium:'Estadio Monterrey', closesIn:'44d 02h', boost:null,
    goalScorer:null, aiPred:'1 · Local (54%)',
    aiText:'Portugal con CR8 todavía marca casi por inercia. Japón es disciplinado, pero no es suficiente.',
    homeColors:['#006600','#FF0000'], awayColors:['#FFFFFF','#BC002D'], pts:5, saved:false },
];

// Camiseta SVG (simplificada) con dos colores principales
function JerseyBg({ colors, side='left' }) {
  const [c1, c2] = colors;
  const stripeId = `stripe-${c1.replace('#','')}-${c2.replace('#','')}-${side}`;
  return (
    <svg viewBox="0 0 200 240" preserveAspectRatio="xMidYMid slice" style={{ width:'100%', height:'100%', position:'absolute', inset:0, opacity:0.95 }}>
      <defs>
        <linearGradient id={stripeId} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={c1}/>
          <stop offset="100%" stopColor={c2}/>
        </linearGradient>
      </defs>
      {/* Camiseta */}
      <path d="M30 40 L70 20 L80 35 L120 35 L130 20 L170 40 L180 90 L150 95 L150 220 L50 220 L50 95 L20 90 Z"
            fill={`url(#${stripeId})`} stroke="rgba(0,0,0,0.15)" strokeWidth="1"/>
      {/* sombras / pliegues */}
      <path d="M50 95 L50 220 L100 220 L100 95 Z" fill="rgba(0,0,0,0.08)"/>
      <path d="M70 20 L100 35 L130 20 L120 35 L100 50 L80 35 Z" fill="rgba(0,0,0,0.18)"/>
    </svg>
  );
}

function PointsBadge({ value, label='pts posibles' }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap: 8 }}>
      <div style={{ width: 24, height: 24, borderRadius: 6, background:'#1F2433', display:'flex', alignItems:'center', justifyContent:'center', border:'1px solid #2A3142' }}>
        <span style={{ fontSize: 13 }}>🎲</span>
      </div>
      <div>
        <span className="fc-num" style={{ fontFamily:'var(--font-display)', fontSize: 18, fontWeight:800, color:'var(--fifa-gold)', letterSpacing:'-0.01em' }}>{value}</span>
        <span style={{ fontSize: 10, color:'rgba(255,255,255,0.55)', marginLeft: 4 }}>{label}</span>
      </div>
    </div>
  );
}

// ── Tarjeta de predicción de Grupos (con animación) ─────────────
function GroupPredictionCard({ data, animateIn=false, delay=0 }) {
  const [home, setHome] = React.useState(data.id===1?2:data.id===2?0:1);
  const [away, setAway] = React.useState(data.id===1?1:data.id===2?2:1);
  const [boostOn, setBoostOn] = React.useState(false);

  const inc = (which, dir) => {
    if (which==='h') setHome(v => Math.max(0, Math.min(9, v+dir)));
    else setAway(v => Math.max(0, Math.min(9, v+dir)));
  };

  return (
    <div style={{
      background: '#0E1320',
      borderRadius: 16,
      border: '1px solid rgba(227,6,19,0.45)',
      boxShadow: '0 0 0 1px rgba(227,6,19,0.15), 0 18px 40px rgba(0,0,0,0.35)',
      overflow: 'hidden',
      animation: animateIn ? `fc-fade-up 0.6s ${delay}ms cubic-bezier(.2,.7,.3,1) both` : 'none',
    }}>
      {/* Hero — camisetas dual */}
      <div style={{ position:'relative', height: 180, display:'grid', gridTemplateColumns:'1fr 1fr' }}>
        <div style={{ position:'relative', overflow:'hidden', background: data.homeColors[0] }}>
          <JerseyBg colors={data.homeColors} side="left"/>
          <div style={{ position:'absolute', left: 14, bottom: 14, color:'#fff', textShadow:'0 2px 8px rgba(0,0,0,0.6)' }}>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 16, fontWeight:800, letterSpacing:'0.02em', lineHeight: 1 }}>{C_NAMES[data.home].toUpperCase()}</div>
            <div style={{ fontSize: 9, fontWeight:700, letterSpacing:'0.18em', opacity: 0.85, marginTop: 4 }}>LOCAL</div>
          </div>
        </div>
        <div style={{ position:'relative', overflow:'hidden', background: data.awayColors[0] }}>
          <JerseyBg colors={data.awayColors} side="right"/>
          <div style={{ position:'absolute', right: 14, bottom: 14, color:'#fff', textAlign:'right', textShadow:'0 2px 8px rgba(0,0,0,0.6)' }}>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 16, fontWeight:800, letterSpacing:'0.02em', lineHeight: 1 }}>{C_NAMES[data.away].toUpperCase()}</div>
            <div style={{ fontSize: 9, fontWeight:700, letterSpacing:'0.18em', opacity: 0.85, marginTop: 4 }}>VISITA</div>
          </div>
        </div>

        {/* Center vs */}
        <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%, -50%)', display:'flex', flexDirection:'column', alignItems:'center', gap: 4 }}>
          <div style={{ background:'rgba(0,0,0,0.7)', backdropFilter:'blur(8px)', borderRadius: 999, padding:'4px 12px', fontSize: 10, fontFamily:'var(--font-display)', fontWeight:600, letterSpacing:'0.04em', color:'rgba(255,255,255,0.85)', whiteSpace:'nowrap' }}>
            Grupo A · {data.stadium}
          </div>
          <div style={{ display:'flex', alignItems:'center', gap: 6 }}>
            <Flag code={data.home} size="lg"/>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 13, fontWeight:800, color:'#fff', textShadow:'0 1px 4px rgba(0,0,0,0.5)' }}>VS</span>
            <Flag code={data.away} size="lg"/>
          </div>
        </div>

        {/* Boost x2 */}
        {data.boost && (
          <div style={{
            position:'absolute', top: 12, right: 12,
            background: 'linear-gradient(135deg, #E30613, #9A0B12)',
            color:'#fff', borderRadius: 8, padding:'5px 9px',
            fontFamily:'var(--font-display)', fontSize: 12, fontWeight:800, letterSpacing:'0.02em',
            boxShadow:'0 4px 12px rgba(227,6,19,0.5)',
          }}>
            x{data.boost}
          </div>
        )}

        {/* Status pill */}
        <div style={{
          position:'absolute', bottom: -12, left:'50%', transform:'translateX(-50%)',
          background:'#00834A', color:'#fff',
          borderRadius: 999, padding:'5px 14px',
          fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, letterSpacing:'0.02em',
          boxShadow:'0 4px 12px rgba(0,131,74,0.4)',
          display:'inline-flex', alignItems:'center', gap: 6,
        }}>
          <span style={{ width: 6, height: 6, borderRadius:'50%', background:'#fff' }}/>
          Abierta · {data.closesIn}
        </div>
      </div>

      {/* Stepper */}
      <div style={{ padding:'24px 18px 12px', display:'flex', justifyContent:'center', gap: 24, alignItems:'center' }}>
        <ScoreColumn value={home} onInc={()=>inc('h',1)} onDec={()=>inc('h',-1)}/>
        <span className="score" style={{ fontSize: 38, color:'rgba(255,255,255,0.4)', fontWeight: 700 }}>:</span>
        <ScoreColumn value={away} onInc={()=>inc('a',1)} onDec={()=>inc('a',-1)}/>
      </div>

      {/* Reward chips */}
      <div style={{ padding:'4px 14px 0', display:'flex', flexWrap:'wrap', gap: 6, justifyContent:'center' }}>
        <RewardChip color="#3B82F6" dot label="+1pt signo"/>
        <RewardChip color="#00834A" icon="⚽" label="+3pts exacto"/>
        <RewardChip color="#1F2433" icon="⚙" label="+2pts goleador"/>
        {data.id===2 && <RewardChip color="#7C3AED" icon="🤖" label="+1pt vs IA"/>}
      </div>

      {/* Goleador selector */}
      <div style={{ padding:'14px 14px 0' }}>
        <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
          <button style={arrowBtn}><Icon name="chev-r" size={14} color="rgba(255,255,255,0.6)" stroke={2.2}/></button>
          <div style={{ flex:1, fontSize: 10, fontFamily:'var(--font-display)', fontWeight:700, letterSpacing:'0.14em', color:'rgba(255,255,255,0.55)', textTransform:'uppercase' }}>GOLEADOR</div>
        </div>
        <div style={{ display:'flex', gap: 8, alignItems:'center', marginTop: 8 }}>
          <div style={{
            flex:1, height: 36, borderRadius: 8, background:'#1F2433', border:'1px solid #2A3142',
            display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 12px',
            fontSize: 12, color:'rgba(255,255,255,0.85)',
          }}>
            <span>{data.goalScorer || 'Selecciona goleador'}</span>
            <Icon name="chev-d" size={14} color="rgba(255,255,255,0.5)"/>
          </div>
          {data.goalScorer && <span style={{ fontSize: 11, color:'rgba(255,255,255,0.6)', fontWeight:600 }}>+2 pts</span>}
        </div>
      </div>

      {/* IA Predice */}
      <div style={{ padding:'14px 14px 0' }}>
        <div style={{ background:'rgba(124,58,237,0.08)', border:'1px solid rgba(124,58,237,0.25)', borderRadius: 10, padding:'10px 12px' }}>
          <div style={{ display:'flex', alignItems:'center', gap: 8, marginBottom: 4 }}>
            <span style={{ width: 6, height: 6, borderRadius:'50%', background:'#A78BFA' }}/>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 10, fontWeight:700, letterSpacing:'0.12em', color:'#A78BFA', textTransform:'uppercase' }}>IA Predice</span>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, color:'#fff', marginLeft:'auto' }}>{data.aiPred}</span>
          </div>
          <div style={{ fontSize: 11, color:'rgba(255,255,255,0.7)', lineHeight: 1.45, fontStyle:'italic' }}>
            {data.aiText}
          </div>
        </div>
      </div>

      {/* Footer actions */}
      <div style={{ padding:'14px', display:'grid', gridTemplateColumns:'1fr auto auto', gap: 8, alignItems:'center' }}>
        <PointsBadge value={data.pts}/>
        <button style={{
          height: 36, padding:'0 16px', borderRadius: 8,
          background: data.saved ? '#00834A' : '#1F2433',
          color:'#fff', border:'none',
          fontFamily:'var(--font-display)', fontSize: 12, fontWeight:700, letterSpacing:'0.02em',
          display:'flex', alignItems:'center', gap: 6, cursor:'pointer',
        }}>
          <Icon name="check" size={14} stroke={2.4}/> Guardado
        </button>
        <button style={{
          height: 36, padding:'0 12px', borderRadius: 8,
          background:'#1F2433', color:'rgba(255,255,255,0.6)', border:'1px solid #2A3142',
          fontFamily:'var(--font-display)', fontSize: 12, fontWeight:600,
          cursor:'pointer',
        }}>↶ Deshacer</button>
      </div>

      {/* Boost row */}
      <div style={{
        padding:'10px 14px', borderTop:'1px solid rgba(255,255,255,0.05)',
        display:'flex', alignItems:'center', gap: 10,
        background: boostOn ? 'rgba(227,6,19,0.08)' : 'transparent',
      }}>
        <button onClick={()=>setBoostOn(!boostOn)} style={{
          width: 18, height: 18, borderRadius: 4,
          background: boostOn ? 'var(--fifa-red)' : 'transparent',
          border: `1.5px solid ${boostOn ? 'var(--fifa-red)' : 'rgba(255,255,255,0.3)'}`,
          display:'flex', alignItems:'center', justifyContent:'center',
          cursor:'pointer', padding:0,
        }}>
          {boostOn && <Icon name="check" size={11} color="#fff" stroke={3}/>}
        </button>
        <span style={{ fontSize: 12, color:'rgba(255,255,255,0.85)', display:'flex', alignItems:'center', gap: 6 }}>
          <span>🔥</span> Boost a este partido
          <span style={{ fontSize: 10, color:'rgba(255,255,255,0.4)', marginLeft: 4 }}>(tap para cambiar)</span>
        </span>
        <span style={{ marginLeft:'auto', fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, color:'#22C55E', display:'flex', alignItems:'center', gap: 4 }}>
          <Icon name="check" size={11} stroke={3}/> Guardado
        </span>
      </div>
    </div>
  );
}

const arrowBtn = {
  width: 28, height: 28, borderRadius:'50%',
  background:'#1F2433', border:'1px solid #2A3142',
  display:'flex', alignItems:'center', justifyContent:'center',
  cursor:'pointer', padding:0,
  transform:'rotate(180deg)',
};

function ScoreColumn({ value, onInc, onDec }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 6 }}>
      <button onClick={onInc} style={triBtn}>
        <svg width="14" height="9" viewBox="0 0 14 9"><path d="M7 0 L14 9 L0 9 Z" fill="rgba(255,255,255,0.5)"/></svg>
      </button>
      <div style={{
        width: 56, height: 56, borderRadius: 12,
        background:'#1F2433', border:'1px solid #2A3142',
        display:'flex', alignItems:'center', justifyContent:'center',
        fontFamily:'var(--font-display)', fontSize: 32, fontWeight:800, color:'#fff',
        fontVariantNumeric:'tabular-nums',
      }}>
        {value}
      </div>
      <button onClick={onDec} style={triBtn}>
        <svg width="14" height="9" viewBox="0 0 14 9"><path d="M7 9 L14 0 L0 0 Z" fill="rgba(255,255,255,0.5)"/></svg>
      </button>
    </div>
  );
}

const triBtn = {
  width: 32, height: 22, borderRadius: 6,
  background:'transparent', border:'none',
  display:'flex', alignItems:'center', justifyContent:'center',
  cursor:'pointer', padding:0,
};

function RewardChip({ color, label, icon, dot }) {
  return (
    <div style={{
      display:'inline-flex', alignItems:'center', gap: 5,
      padding:'5px 10px', borderRadius: 999,
      background: '#1F2433', border:`1px solid ${color}`,
      fontFamily:'var(--font-display)', fontSize: 10, fontWeight:700, color:'#fff',
      letterSpacing:'0.02em',
    }}>
      {dot && <span style={{ width: 6, height: 6, borderRadius:'50%', background: color }}/>}
      {icon && <span style={{ fontSize: 11 }}>{icon}</span>}
      {label}
    </div>
  );
}

// ── Pantalla GRUPOS ─────────────────────────────────────────
function ScreenGrupos({ density='cozy' }) {
  return (
    <div className={`fc-screen density-${density} dark`} style={{ background:'#0A0E1A' }}>
      {/* Header sticky */}
      <div style={{
        paddingTop: 50, padding:'50px 14px 12px',
        background:'linear-gradient(180deg, #0A0E1A, #0A0E1A 85%, transparent)',
        position:'relative', zIndex: 5,
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <button style={{ background:'transparent', border:'none', color:'#22C55E', fontSize: 14, fontWeight:600, display:'flex', alignItems:'center', gap: 4, padding: 0, cursor:'pointer' }}>
            <Icon name="chev-r" size={14} color="#22C55E" stroke={2.4}/> Grupos
          </button>
          <div style={{ fontFamily:'var(--font-display)', fontSize: 17, fontWeight:800, color:'#fff' }}>Grupo A</div>
          <button style={{ width: 34, height: 34, borderRadius: 8, background:'#1F2433', border:'1px solid #2A3142', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer' }}>
            <Icon name="trophy" size={16} color="#A78BFA"/>
          </button>
        </div>

        <div style={{ textAlign:'center', marginTop: 10 }}>
          <div style={{ fontSize: 12, color:'rgba(255,255,255,0.55)', fontStyle:'italic' }}>
            Grupo completo. Pura casta quinielera.
          </div>
        </div>

        {/* Progreso del grupo */}
        <div style={{ display:'flex', justifyContent:'center', gap: 6, marginTop: 12 }}>
          {[1,2,3,4,5,6].map(i => (
            <div key={i} style={{
              width: 24, height: 24, borderRadius:'50%',
              background:'#22C55E',
              display:'flex', alignItems:'center', justifyContent:'center',
              boxShadow:'0 0 0 2px rgba(34,197,94,0.2)',
            }}>
              <Icon name="check" size={12} color="#fff" stroke={3}/>
            </div>
          ))}
          <div style={{
            width: 24, height: 24, borderRadius:'50%',
            background:'#1F2433', border:'1.5px dashed rgba(255,255,255,0.2)',
            display:'flex', alignItems:'center', justifyContent:'center', fontSize: 11,
          }}>🎯</div>
        </div>
        <div style={{ height: 2, background:'#22C55E', borderRadius: 999, marginTop: 14, opacity: 0.6 }}/>
      </div>

      <div className="fc-scroll" style={{ padding:'14px 14px 12px' }}>
        {GROUP_FIXTURES.map((f, i) => (
          <React.Fragment key={f.id}>
            <GroupPredictionCard data={f} animateIn delay={i*120}/>
            <div style={{ height: 14 }}/>
          </React.Fragment>
        ))}
        <div style={{ height: 8 }}/>
      </div>

      <BottomTabs active="grupos" dark/>
    </div>
  );
}

// ── Pantalla JORNADA ────────────────────────────────────────
function ScreenJornada({ density='cozy' }) {
  return (
    <div className={`fc-screen density-${density}`}>
      <div style={{ paddingTop: 56, padding:'56px 18px 0' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 14 }}>
          <span className="fc-eyebrow">JORNADA 3 · GRUPOS</span>
          <div style={{ display:'flex', gap: 6, alignItems:'center' }}>
            <button style={chevBtn}><Icon name="chev-r" size={14} color="var(--ink-500)" stroke={2.2}/></button>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 12, fontWeight:700, color:'var(--ink-700)' }}>14–16 JUN</span>
            <button style={{ ...chevBtn, transform:'none' }}><Icon name="chev-r" size={14} color="var(--ink-500)" stroke={2.2}/></button>
          </div>
        </div>

        <h1 style={{ fontFamily:'var(--font-display)', fontSize: 30, fontWeight:800, letterSpacing:'-0.02em', margin:'0 0 4px' }}>
          Resultados
        </h1>
        <div style={{ fontSize: 13, color:'var(--ink-500)' }}>8 partidos · 6 finalizados · 2 por jugar</div>
      </div>

      <div className="fc-scroll" style={{ padding:'18px 18px 12px' }}>
        <div className="fc-eyebrow" style={{ marginBottom: 10 }}>FINALIZADOS</div>
        <div style={{ display:'flex', flexDirection:'column', gap: 10 }}>
          <MatchB home="MEX" away="ARG" hs={2} as={1} status="final" when="DOM 14:00" venue="ESTADIO AZTECA · CDMX"/>
          <MatchB home="ESP" away="BRA" hs={1} as={1} status="final" when="DOM 17:00" venue="METLIFE · NJ"/>
          <MatchB home="FRA" away="GER" hs={3} as={2} status="final" when="DOM 20:00" venue="SOFI STADIUM · LA"/>
          <MatchB home="POR" away="JPN" hs={2} as={0} status="final" when="LUN 14:00" venue="BMO FIELD · TORONTO"/>
        </div>

        <div className="fc-eyebrow" style={{ marginTop: 22, marginBottom: 10 }}>EN VIVO</div>
        <MatchB home="ENG" away="ITA" hs={1} as={0} status="live" minute={67} venue="ESTADIO MONTERREY"/>

        <div className="fc-eyebrow" style={{ marginTop: 22, marginBottom: 10 }}>PRÓXIMOS PARTIDOS</div>
        <div style={{ display:'flex', flexDirection:'column', gap: 8 }}>
          <MatchC home="USA" away="POR" when="MAÑ 18:30" status="upcoming"/>
          <MatchC home="NED" away="URU" when="MIE 14:00" status="upcoming"/>
          <MatchC home="CRO" away="MAR" when="MIE 17:00" status="upcoming"/>
        </div>

        <div style={{ height: 12 }}/>
      </div>

      <BottomTabs active="jornada"/>
    </div>
  );
}

const chevBtn = {
  width: 28, height: 28, borderRadius:'50%',
  background:'var(--ink-100)', border:'none',
  display:'flex', alignItems:'center', justifyContent:'center',
  cursor:'pointer', padding:0, transform:'rotate(180deg)',
};

// ── Pantalla DIRECTO (simplificada — sin stats ampliadas) ───────
function ScreenDirecto({ density='cozy' }) {
  return (
    <div className={`fc-screen dark density-${density}`}>
      <div style={{
        paddingTop: 56, padding:'56px 18px 0',
        background: 'linear-gradient(180deg, #0A0E1A 0%, #1A2138 100%)',
        position:'relative', overflow:'hidden',
      }}>
        <div style={{ position:'absolute', right:-60, top:0, width: 280, height: 280, borderRadius:'50%', background:'radial-gradient(circle, rgba(201,169,97,0.12) 0%, transparent 70%)' }}/>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 18 }}>
          <button style={btnGhost}><Icon name="chev-r" size={18} color="#fff" stroke={2.4}/></button>
          <div style={{ display:'flex', alignItems:'center', gap: 6 }}>
            <span className="fc-live-dot"></span>
            <span style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, letterSpacing:'0.12em', color:'#fff' }}>EN VIVO · 67'</span>
          </div>
          <button style={btnGhost}><Icon name="bell" size={18} color="#fff"/></button>
        </div>

        <div className="fc-eyebrow" style={{ color:'rgba(255,255,255,0.5)', textAlign:'center', marginBottom: 4 }}>GRUPO A · J3</div>
        <div style={{ fontSize: 11, color:'rgba(255,255,255,0.4)', textAlign:'center', marginBottom: 22 }}>Estadio Azteca · CDMX</div>

        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', position:'relative' }}>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 8, width: 90 }}>
            <Flag code="MEX" size="xl"/>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 14, fontWeight:700, color:'#fff' }}>MÉXICO</div>
          </div>
          <div style={{ flex:1, textAlign:'center' }}>
            <div className="score" style={{ fontSize: 72, color:'#fff', lineHeight: 1, fontWeight: 800 }}>
              2<span style={{ color:'rgba(255,255,255,0.2)', margin:'0 14px' }}>−</span>1
            </div>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 11, fontWeight:700, letterSpacing:'0.12em', color:'var(--fifa-red)', marginTop: 10 }}>
              2T · 67'
            </div>
          </div>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap: 8, width: 90 }}>
            <Flag code="ARG" size="xl"/>
            <div style={{ fontFamily:'var(--font-display)', fontSize: 14, fontWeight:700, color:'#fff' }}>ARGENTINA</div>
          </div>
        </div>
      </div>

      <div className="fc-scroll" style={{ padding:'22px 18px 12px', background: 'var(--ink-900)' }}>
        {/* Goleadores */}
        <div className="fc-eyebrow" style={{ color:'rgba(255,255,255,0.5)', marginBottom: 12 }}>GOLEADORES</div>

        <div style={{ display:'grid', gridTemplateColumns:'1fr auto 1fr', gap: 14, alignItems:'start' }}>
          <div>
            <ScorerRow flag="MEX" name="Lozano" minute="23'" align="left"/>
            <ScorerRow flag="MEX" name="Giménez" minute="54'" align="left"/>
          </div>
          <div style={{ width: 1, alignSelf:'stretch', background:'rgba(255,255,255,0.08)' }}/>
          <div>
            <ScorerRow flag="ARG" name="Álvarez" minute="61'" align="right"/>
          </div>
        </div>

        {/* Tu predicción */}
        <div style={{ marginTop: 22, padding: 14, borderRadius: 14, background:'var(--ink-800)', border:'1px solid var(--ink-700)' }}>
          <div className="fc-eyebrow" style={{ color:'rgba(255,255,255,0.5)', marginBottom: 8 }}>TU PREDICCIÓN</div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div className="score" style={{ fontSize: 22, color:'#fff' }}>2<span style={{ margin:'0 8px', color:'rgba(255,255,255,0.3)' }}>:</span>1</div>
            <span className="pred-chip" style={{ background:'rgba(0,131,74,0.15)', color:'#4DD49B' }}>Vas ganando · +50 pts</span>
          </div>
        </div>

        {/* Otros directos */}
        <div className="fc-eyebrow" style={{ color:'rgba(255,255,255,0.5)', marginTop: 22, marginBottom: 12 }}>OTROS PARTIDOS EN VIVO</div>
        <div style={{ display:'flex', flexDirection:'column', gap: 8 }}>
          <LiveMiniRow home="ENG" away="ITA" hs={1} as={0} minute={32}/>
          <LiveMiniRow home="NED" away="URU" hs={0} as={0} minute={12}/>
        </div>

        <div style={{ height: 12 }}/>
      </div>

      <BottomTabs active="directo" dark/>
    </div>
  );
}

function ScorerRow({ flag, name, minute, align='left' }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: 8, marginBottom: 8,
      flexDirection: align==='right' ? 'row-reverse' : 'row',
    }}>
      <span style={{ fontSize: 14 }}>⚽</span>
      <div style={{ textAlign: align }}>
        <div style={{ fontFamily:'var(--font-display)', fontSize: 13, fontWeight:700, color:'#fff' }}>{name}</div>
        <div className="fc-num" style={{ fontSize: 10, color:'rgba(255,255,255,0.5)' }}>{minute}</div>
      </div>
    </div>
  );
}

function LiveMiniRow({ home, away, hs, as, minute }) {
  return (
    <div style={{
      background:'var(--ink-800)', border:'1px solid var(--ink-700)',
      borderRadius: 12, padding:'10px 14px',
      display:'grid', gridTemplateColumns:'auto 1fr auto 1fr auto auto', gap: 10, alignItems:'center',
    }}>
      <Flag code={home}/>
      <span style={{ fontWeight:600, fontSize: 13, color:'#fff' }}>{home}</span>
      <span className="score" style={{ fontSize: 16, color:'#fff', minWidth: 38, textAlign:'center' }}>{hs}–{as}</span>
      <span style={{ fontWeight:600, fontSize: 13, color:'#fff', textAlign:'right' }}>{away}</span>
      <Flag code={away}/>
      <span style={{ display:'inline-flex', alignItems:'center', gap: 4, fontFamily:'var(--font-display)', fontSize: 10, fontWeight:700, color:'var(--fifa-red)', letterSpacing:'0.04em' }}>
        <span className="fc-live-dot"></span>{minute}'
      </span>
    </div>
  );
}

// Animaciones
if (typeof document !== 'undefined' && !document.getElementById('fc-anim-styles')) {
  const s = document.createElement('style');
  s.id = 'fc-anim-styles';
  s.textContent = `
    @keyframes fc-fade-up {
      from { opacity: 0; transform: translateY(24px) scale(0.98); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
  `;
  document.head.appendChild(s);
}

Object.assign(window, { ScreenGrupos, ScreenJornada, ScreenDirecto, GroupPredictionCard, JerseyBg });
